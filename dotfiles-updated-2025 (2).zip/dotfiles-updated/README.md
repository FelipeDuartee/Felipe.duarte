# dotfiles — BugBounty & Pentest Environment (Updated 2025)

![dotfiles](images/dotfile.png)

## What's new in this update

- **Go tools**: All updated to latest versions. `nuclei v3`, `amass v4`, `ffuf v2`, `gowitness v3`
- **New tools**: `tlsx`, `asnmap`, `uncover`, `cvemap`, `pdtm`, `cloudlist`, `gau v2`, `SubOver`, `S3Scanner`, `nomore403`, `CORScanner`, `cloud_enum`
- **Deprecated removed**: `crobat` (defunct), `mildew` (replaced), `altdns` (replaced by `alterx`)
- **Nuclei templates**: Updated to v3 syntax (`http:` instead of `requests:`), added GraphQL, cloud exposure
- **Wordlists**: Updated API routes (2024), added LFI/SQLi/SSTI/open-redirect payloads, trusted resolvers
- **functions.zsh**: All functions updated, new: `tlsEnum()`, `sqliScan()`, `sstiScan()`, `cloudEnum()`, `subtakeover()`, `arjunScan()`, `bypass4xx()` (improved), `cveScan()`, `bb_help()`

## Recon Workflow

```
workspaceRecon <domain>    # setup workspace
subdomainenum              # passive sub enum
tlsEnum                    # TLS + SAN discovery
naabuRecon                 # port scan
getalive                   # HTTP probe
crawler                    # crawl + URL harvest
getjsurls                  # JS extraction
APIRecon                   # API endpoint discovery
nuclei + custom templates  # vuln scan
```

## Quick install

```bash
bash setup/install_hacktools.sh
```

## Directory structure

```
config/
  zsh/
    functions.zsh     ← all recon/scan functions
    alias.zsh
  home/.gf/           ← gf patterns
custom_nuclei_templates/
  api-recon.yaml
  swagger-ui.yaml
  graphql-recon.yaml        (NEW)
  cloud-exposure.yaml       (NEW)
  api-recon-workflow.yaml
  m4cddr-takeovers.yaml
  sap-netweaver-workflow.yaml
mongodb/              ← result storage (pymongo)
setup/
  install_hacktools.sh
Lists/                ← auto-downloaded wordlists
```

## Tools summary

| Category | Tools |
|---|---|
| Subdomain | subfinder, amass v4, assetfinder, github-subdomains, gitlab-subdomains, chaos, uncover |
| DNS | dnsx, shuffledns, puredns, hakrevdns |
| TLS | tlsx |
| Ports | naabu, mapcidr |
| HTTP | httpx, hakcheckurl |
| Crawl | katana, gospider, hakrawler, gau v2, waybackurls, waymore, subjs, getJS |
| Vuln | nuclei v3, interactsh, cvemap |
| XSS | dalfox, kxss, Gxss, airixss, freq |
| Fuzzing | ffuf v2, qsreplace, gf, dirdar, feroxbuster |
| Params | arjun, ParamSpider |
| Cloud | cloudlist, S3Scanner, cloud_enum, asnmap |
| Secrets | SecretFinder, trufflehog3, gitleaks |
| Takeover | SubOver, nuclei takeover templates |
| Screenshots | gowitness v3 |
| Notify | notify |
