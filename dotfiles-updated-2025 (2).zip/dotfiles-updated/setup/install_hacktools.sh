#!/usr/bin/env bash

# =============================================================================
# BugBounty / Pentest Toolchain Installer - UPDATED 2025
# =============================================================================

DEBUG_STD="&>/dev/null"
DEBUG_ERROR="2>/dev/null"

bblue='\033[1;34m'
bgreen='\033[1;32m'
bred='\033[1;31m'
byellow='\033[1;33m'
reset='\033[0m'

dir="$HOME/Tools"
LISTS="$HOME/Lists"
GF_DIR="$HOME/.gf"

check_go() {
  if ! command -v go &>/dev/null; then
    echo -e "${bred}[!] Go not found. Please install Go >= 1.21 first.${reset}"
    exit 1
  fi
  echo -e "${bgreen}[+] Go version: $(go version | awk '{print $3}')${reset}"
}

check_python() {
  if ! command -v python3 &>/dev/null; then
    echo -e "${bred}[!] Python3 not found.${reset}"
    exit 1
  fi
}

mkdir -p "$dir" "$LISTS" "$GF_DIR" \
  "$HOME/.config/notify/" "$HOME/.config/amass/" \
  "$HOME/.config/nuclei/" "$HOME/.config/subfinder/"

check_go
check_python

printf "${bblue}[*] Installing Go-based tools (latest)${reset}\n\n"
go env -w GO111MODULE=auto
go env -w GOFLAGS="-mod=mod"

install_go_tool() {
  local name="$1" repo="$2"
  echo -e "${byellow}[~] $name${reset}"
  if go install "$repo"@latest 2>/dev/null; then
    echo -e "${bgreen}[+] $name OK${reset}"
  else
    echo -e "${bred}[-] $name FAILED — go install $repo@latest${reset}"
  fi
}

# Recon / Subdomain
install_go_tool "subfinder"         "github.com/projectdiscovery/subfinder/v2/cmd/subfinder"
install_go_tool "amass"             "github.com/owasp-amass/amass/v4/..."
install_go_tool "assetfinder"       "github.com/tomnomnom/assetfinder"
install_go_tool "github-subdomains" "github.com/gwen001/github-subdomains"
install_go_tool "gitlab-subdomains" "github.com/gwen001/gitlab-subdomains"
install_go_tool "gotator"           "github.com/Josue87/gotator"
install_go_tool "alterx"            "github.com/projectdiscovery/alterx/cmd/alterx"
install_go_tool "metabigor"         "github.com/j3ssie/metabigor"
install_go_tool "sdlookup"          "github.com/j3ssie/sdlookup"

# DNS
install_go_tool "dnsx"              "github.com/projectdiscovery/dnsx/cmd/dnsx"
install_go_tool "shuffledns"        "github.com/projectdiscovery/shuffledns/cmd/shuffledns"
install_go_tool "puredns"           "github.com/d3mondev/puredns/v2"
install_go_tool "hakrevdns"         "github.com/hakluke/hakrevdns"

# Port Scanning / Asset Discovery
install_go_tool "naabu"             "github.com/projectdiscovery/naabu/v2/cmd/naabu"
install_go_tool "mapcidr"           "github.com/projectdiscovery/mapcidr/cmd/mapcidr"
install_go_tool "tlsx"              "github.com/projectdiscovery/tlsx/cmd/tlsx"
install_go_tool "asnmap"            "github.com/projectdiscovery/asnmap/cmd/asnmap"
install_go_tool "uncover"           "github.com/projectdiscovery/uncover/cmd/uncover"   # shodan/fofa/censys
install_go_tool "cloudlist"         "github.com/projectdiscovery/cloudlist/cmd/cloudlist"

# HTTP Probing
install_go_tool "httpx"             "github.com/projectdiscovery/httpx/cmd/httpx"
install_go_tool "hakcheckurl"       "github.com/hakluke/hakcheckurl"
install_go_tool "rush"              "github.com/shenwei356/rush"

# Crawling / URL Harvesting
install_go_tool "katana"            "github.com/projectdiscovery/katana/cmd/katana"
install_go_tool "gospider"          "github.com/jaeles-project/gospider"
install_go_tool "hakrawler"         "github.com/hakluke/hakrawler"
install_go_tool "waybackurls"       "github.com/tomnomnom/waybackurls"
install_go_tool "gauplus"           "github.com/bp0lr/gauplus"
install_go_tool "gau"               "github.com/lc/gau/v2/cmd/gau"
install_go_tool "subjs"             "github.com/lc/subjs"
install_go_tool "getJS"             "github.com/003random/getJS"
install_go_tool "fff"               "github.com/tomnomnom/fff"
install_go_tool "meg"               "github.com/tomnomnom/meg"

# Vulnerability Scanning
install_go_tool "nuclei"            "github.com/projectdiscovery/nuclei/v3/cmd/nuclei"
install_go_tool "interactsh-client" "github.com/projectdiscovery/interactsh/cmd/interactsh-client"
install_go_tool "notify"            "github.com/projectdiscovery/notify/cmd/notify"
install_go_tool "cvemap"            "github.com/projectdiscovery/cvemap/cmd/cvemap"   # CVE mapping NEW
install_go_tool "pdtm"              "github.com/projectdiscovery/pdtm/cmd/pdtm"       # pd tool manager NEW

# XSS
install_go_tool "dalfox"            "github.com/hahwul/dalfox/v2"
install_go_tool "kxss"              "github.com/tomnomnom/hacks/kxss"
install_go_tool "Gxss"              "github.com/KathanP19/Gxss"
install_go_tool "airixss"           "github.com/ferreiraklet/airixss"
install_go_tool "freq"              "github.com/takshal/freq"

# Params / Fuzzing
install_go_tool "ffuf"              "github.com/ffuf/ffuf/v2"
install_go_tool "qsreplace"         "github.com/tomnomnom/qsreplace"
install_go_tool "gf"                "github.com/tomnomnom/gf"
install_go_tool "anew"              "github.com/tomnomnom/anew"
install_go_tool "unfurl"            "github.com/tomnomnom/unfurl"
install_go_tool "gron"              "github.com/tomnomnom/gron"
install_go_tool "html-tool"         "github.com/tomnomnom/hacks/html-tool"
install_go_tool "tojson"            "github.com/tomnomnom/hacks/tojson"

# SSRF / Headers / Misc
install_go_tool "hakip2host"        "github.com/hakluke/hakip2host"
install_go_tool "gowitness"         "github.com/sensepost/gowitness/v3"
install_go_tool "dirdar"            "github.com/m4dm0e/dirdar"
install_go_tool "scopein"           "github.com/ferreiraklet/scopein"
install_go_tool "chaos"             "github.com/projectdiscovery/chaos-client/cmd/chaos"
install_go_tool "sourcemapper"      "github.com/denandz/sourcemapper"
install_go_tool "mildew"            "github.com/daehee/mildew/cmd/mildew"
install_go_tool "nilo"              "github.com/ferreiraklet/nilo"

# =============================================================================
printf "\n${bblue}[*] Installing Python tools${reset}\n\n"
# =============================================================================

pip_install() {
  local pkg="$1"
  echo -e "${byellow}[~] pip install $pkg${reset}"
  pip3 install "$pkg" --break-system-packages -q 2>/dev/null || \
  pip3 install "$pkg" -q 2>/dev/null && echo -e "${bgreen}[+] $pkg${reset}"
}

pip_install uro
pip_install bhedak
pip_install arjun          # param discovery (actively maintained)
pip_install waymore        # wayback+common crawl
pip_install trufflehog3    # secrets in repos/filesystems

# =============================================================================
printf "\n${bblue}[*] Cloning Git repositories${reset}\n\n"
# =============================================================================

declare -A repos
repos["gf"]="tomnomnom/gf"
repos["Gf-Patterns"]="1ndianl33t/Gf-Patterns"
repos["LinkFinder"]="GerbenJavado/LinkFinder"
repos["Interlace"]="codingo/Interlace"
repos["JSScanner"]="0x240x23elu/JSScanner"
repos["GitTools"]="internetwache/GitTools"
repos["SecretFinder"]="m4ll0k/SecretFinder"
repos["BBTz"]="m4ll0k/BBTz"
repos["git-dumper"]="arthaud/git-dumper"
repos["CORStest"]="RUB-NDS/CORStest"
repos["CORScanner"]="chenjj/CORScanner"          # NEW dedicated CORS scanner
repos["Knock"]="guelfoweb/knock"
repos["Photon"]="s0md3v/Photon"
repos["DNSvalidator"]="vortexau/dnsvalidator"
repos["Massdns"]="blechschmidt/massdns"
repos["Dirsearch"]="maurosoria/dirsearch"
repos["knoxnl"]="xnl-h4ck3r/knoxnl"
repos["xnLinkFinder"]="xnl-h4ck3r/xnLinkFinder"
repos["Waymore"]="xnl-h4ck3r/waymore"
repos["ParamSpider"]="devanshbatham/paramspider"
repos["XSStrike"]="s0md3v/XSStrike"              # upstream active
repos["MSwellDOTS"]="mswell/dotfiles"
repos["FavFreak"]="devanshbatham/FavFreak"
repos["smuggler"]="defparam/smuggler"
repos["nomore403"]="devploit/nomore403"          # NEW 403 bypass
repos["cloud_enum"]="initstring/cloud_enum"      # NEW cloud assets
repos["SubOver"]="Ice3man543/SubOver"            # NEW subdomain takeover
repos["S3Scanner"]="sa7mon/S3Scanner"            # NEW S3 bucket scanner
repos["leakix-searchcli"]="LeakIX/l9filter"     # NEW LeakIX

repos_step=0
for repo in "${!repos[@]}"; do
  repos_step=$((repos_step + 1))
  echo -e "${byellow}[~] $repo (${repos_step}/${#repos[@]})${reset}"
  if [ -d "$dir/$repo" ]; then
    cd "$dir/$repo" && git pull -q && cd "$dir"
  else
    git clone -q "https://github.com/${repos[$repo]}" "$dir/$repo"
  fi
  cd "$dir/$repo" 2>/dev/null || continue
  [ -s "requirements.txt" ] && pip3 install -r requirements.txt --break-system-packages -q 2>/dev/null
  [ -s "setup.py" ]         && python3 setup.py install -q 2>/dev/null
  [ -s "Makefile" ]         && make -s 2>/dev/null && make install -s 2>/dev/null
  if [ "gf" = "$repo" ]; then
    cp -r examples/*.json "$GF_DIR/" 2>/dev/null
  elif [ "Gf-Patterns" = "$repo" ]; then
    cp *.json "$GF_DIR/" 2>/dev/null
  fi
  cd "$dir"
done

# =============================================================================
printf "\n${bblue}[*] Downloading wordlists${reset}\n\n"
# =============================================================================

dl() {
  local dest="$1" url="$2"
  if [ ! -f "$dest" ]; then
    echo -e "${byellow}[~] $(basename $dest)${reset}"
    wget -q -O "$dest" "$url" && echo -e "${bgreen}[+] $(basename $dest)${reset}" || echo -e "${bred}[-] FAILED: $url${reset}"
  else
    echo "[=] $(basename $dest) exists, skip"
  fi
}

BASE="https://raw.githubusercontent.com/danielmiessler/SecLists/master"

# Always refresh resolvers
wget -q -O "$LISTS/resolvers.txt"         "https://raw.githubusercontent.com/trickest/resolvers/main/resolvers.txt"
wget -q -O "$LISTS/resolvers-trusted.txt" "https://raw.githubusercontent.com/trickest/resolvers/main/resolvers-trusted.txt"

dl "$LISTS/XSS-OFJAAAH.txt"                  "$BASE/Fuzzing/XSS/XSS-OFJAAAH.txt"
dl "$LISTS/XSS-Jhaddix.txt"                  "$BASE/Fuzzing/XSS/XSS-Jhaddix.txt"
dl "$LISTS/params.txt"                        "$BASE/Discovery/Web-Content/burp-parameter-names.txt"
dl "$LISTS/raft-large-directories.txt"        "$BASE/Discovery/Web-Content/raft-large-directories.txt"
dl "$LISTS/raft-large-directories-lower.txt"  "$BASE/Discovery/Web-Content/raft-large-directories-lowercase.txt"
dl "$LISTS/raft-large-files.txt"              "$BASE/Discovery/Web-Content/raft-large-files.txt"
dl "$LISTS/raft-large-words.txt"              "$BASE/Discovery/Web-Content/raft-large-words.txt"
dl "$LISTS/raft-medium-directories.txt"       "$BASE/Discovery/Web-Content/raft-medium-directories.txt"
dl "$LISTS/web-extensions.txt"                "$BASE/Discovery/Web-Content/web-extensions.txt"
dl "$LISTS/namelist.txt"                      "$BASE/Discovery/DNS/namelist.txt"
dl "$LISTS/subdomains-top1million-5000.txt"   "$BASE/Discovery/DNS/subdomains-top1million-5000.txt"
dl "$LISTS/subdomains-top1million-110000.txt" "$BASE/Discovery/DNS/subdomains-top1million-110000.txt"
dl "$LISTS/xato-net-10million-usernames.txt"  "$BASE/Usernames/xato-net-10-million-usernames.txt"
dl "$LISTS/lfi-payloads.txt"                  "$BASE/Fuzzing/LFI/LFI-Jhaddix.txt"
dl "$LISTS/sqli-payloads.txt"                 "$BASE/Fuzzing/SQLi/Generic-SQLi.txt"
dl "$LISTS/ssti-payloads.txt"                 "$BASE/Fuzzing/template-engines-special-vars.txt"
dl "$LISTS/open-redirect.txt"                 "$BASE/Fuzzing/redirect/open-redirect-payloads.txt"
dl "$LISTS/all.txt"                           "https://gist.githubusercontent.com/jhaddix/86a06c5dc309d08580a018c66354a056/raw/96f4e51d96b2203f19f6381c8c545b278eaa0837/all.txt"
dl "$LISTS/httparchive_apiroutes.txt"         "https://wordlists-cdn.assetnote.io/data/automated/httparchive_apiroutes_2024_02_19.txt"

wget -q -O "$GF_DIR/potential.json" \
  "https://raw.githubusercontent.com/devanshbatham/ParamSpider/master/gf_profiles/potential.json" 2>/dev/null

# Copy custom GF patterns
[ -d "$HOME/Tools/MSwellDOTS/config/home/.gf" ] && \
  cp -r "$HOME/Tools/MSwellDOTS/config/home/.gf/"*.json "$GF_DIR/" 2>/dev/null

# Update nuclei templates
echo -e "${byellow}[~] Updating nuclei templates...${reset}"
nuclei -update-templates 2>/dev/null || true

printf "\n${bgreen}[+] Done! Restart your shell or: source ~/.zshrc${reset}\n"
