#!/usr/bin/env bash

# =============================================================================
# BugBounty / Pentest Toolchain Installer - UPDATED 2025 v4
# Alinhado ao MITRE ATT&CK — suporte completo ao functions_v4.zsh
# =============================================================================

bblue='\033[1;34m'
bgreen='\033[1;32m'
bred='\033[1;31m'
byellow='\033[1;33m'
reset='\033[0m'

dir="$HOME/Tools"
LISTS="$HOME/Lists"
GF_DIR="$HOME/.gf"

check_go() {
  if ! command -v go &>/dev/null; then
    echo -e "${bred}[!] Go não encontrado. Instalando Go 1.22...${reset}"
    cd /tmp
    wget -q "https://go.dev/dl/go1.22.3.linux-amd64.tar.gz"
    sudo tar -C /usr/local -xzf go1.22.3.linux-amd64.tar.gz
    export PATH=$PATH:/usr/local/go/bin
    echo 'export PATH=$PATH:/usr/local/go/bin' >> "$HOME/.zshrc"
    echo 'export PATH=$PATH:$HOME/go/bin' >> "$HOME/.zshrc"
    cd -
  fi
  echo -e "${bgreen}[+] Go: $(go version | awk '{print $3}')${reset}"
}

check_python() {
  if ! command -v python3 &>/dev/null; then
    echo -e "${bred}[!] Python3 não encontrado.${reset}"
    exit 1
  fi
  echo -e "${bgreen}[+] Python: $(python3 --version)${reset}"
}

mkdir -p "$dir" "$LISTS" "$GF_DIR" \
  "$HOME/.config/notify/" "$HOME/.config/amass/" \
  "$HOME/.config/nuclei/" "$HOME/.config/subfinder/" \
  "$HOME/custom_nuclei_templates/"

check_go
check_python

export PATH=$PATH:/usr/local/go/bin:$HOME/go/bin
go env -w GO111MODULE=auto
go env -w GOFLAGS="-mod=mod"

# =============================================================================
printf "\n${bblue}[*] Instalando ferramentas Go (latest)${reset}\n\n"
# =============================================================================

install_go_tool() {
  local name="$1" repo="$2"
  printf "${byellow}  [~] %-30s${reset}" "$name"
  if go install "$repo"@latest 2>/dev/null; then
    echo -e " ${bgreen}OK${reset}"
  else
    echo -e " ${bred}FALHOU — go install $repo@latest${reset}"
  fi
}

echo -e "\n${bblue}[>] Subdomain Enumeration${reset}"
install_go_tool "subfinder"         "github.com/projectdiscovery/subfinder/v2/cmd/subfinder"
install_go_tool "amass"             "github.com/owasp-amass/amass/v4/..."
install_go_tool "assetfinder"       "github.com/tomnomnom/assetfinder"
install_go_tool "github-subdomains" "github.com/gwen001/github-subdomains"
install_go_tool "gitlab-subdomains" "github.com/gwen001/gitlab-subdomains"
install_go_tool "alterx"            "github.com/projectdiscovery/alterx/cmd/alterx"
install_go_tool "gotator"           "github.com/Josue87/gotator"
install_go_tool "chaos"             "github.com/projectdiscovery/chaos-client/cmd/chaos"

echo -e "\n${bblue}[>] DNS${reset}"
install_go_tool "dnsx"              "github.com/projectdiscovery/dnsx/cmd/dnsx"
install_go_tool "shuffledns"        "github.com/projectdiscovery/shuffledns/cmd/shuffledns"
install_go_tool "puredns"           "github.com/d3mondev/puredns/v2"
install_go_tool "hakrevdns"         "github.com/hakluke/hakrevdns"

echo -e "\n${bblue}[>] Port Scanning & Asset Discovery${reset}"
install_go_tool "naabu"             "github.com/projectdiscovery/naabu/v2/cmd/naabu"
install_go_tool "mapcidr"           "github.com/projectdiscovery/mapcidr/cmd/mapcidr"
install_go_tool "tlsx"              "github.com/projectdiscovery/tlsx/cmd/tlsx"
install_go_tool "asnmap"            "github.com/projectdiscovery/asnmap/cmd/asnmap"
install_go_tool "uncover"           "github.com/projectdiscovery/uncover/cmd/uncover"
install_go_tool "cloudlist"         "github.com/projectdiscovery/cloudlist/cmd/cloudlist"

echo -e "\n${bblue}[>] HTTP Probing${reset}"
install_go_tool "httpx"             "github.com/projectdiscovery/httpx/cmd/httpx"
install_go_tool "hakcheckurl"       "github.com/hakluke/hakcheckurl"
install_go_tool "rush"              "github.com/shenwei356/rush"

echo -e "\n${bblue}[>] Crawling & URL Harvesting${reset}"
install_go_tool "katana"            "github.com/projectdiscovery/katana/cmd/katana"
install_go_tool "gospider"          "github.com/jaeles-project/gospider"
install_go_tool "hakrawler"         "github.com/hakluke/hakrawler"
install_go_tool "waybackurls"       "github.com/tomnomnom/waybackurls"
install_go_tool "gau"               "github.com/lc/gau/v2/cmd/gau"
install_go_tool "subjs"             "github.com/lc/subjs"
install_go_tool "getJS"             "github.com/003random/getJS"
install_go_tool "fff"               "github.com/tomnomnom/fff"
install_go_tool "meg"               "github.com/tomnomnom/meg"

echo -e "\n${bblue}[>] Vulnerability Scanning${reset}"
install_go_tool "nuclei"            "github.com/projectdiscovery/nuclei/v3/cmd/nuclei"
install_go_tool "interactsh-client" "github.com/projectdiscovery/interactsh/cmd/interactsh-client"
install_go_tool "notify"            "github.com/projectdiscovery/notify/cmd/notify"
install_go_tool "cvemap"            "github.com/projectdiscovery/cvemap/cmd/cvemap"
install_go_tool "pdtm"              "github.com/projectdiscovery/pdtm/cmd/pdtm"

echo -e "\n${bblue}[>] XSS${reset}"
install_go_tool "dalfox"            "github.com/hahwul/dalfox/v2"
install_go_tool "kxss"              "github.com/tomnomnom/hacks/kxss"
install_go_tool "Gxss"              "github.com/KathanP19/Gxss"
install_go_tool "airixss"           "github.com/ferreiraklet/airixss"
install_go_tool "freq"              "github.com/takshal/freq"

echo -e "\n${bblue}[>] Params, Fuzzing & Misc${reset}"
install_go_tool "ffuf"              "github.com/ffuf/ffuf/v2"
install_go_tool "qsreplace"         "github.com/tomnomnom/qsreplace"
install_go_tool "gf"                "github.com/tomnomnom/gf"
install_go_tool "anew"              "github.com/tomnomnom/anew"
install_go_tool "unfurl"            "github.com/tomnomnom/unfurl"
install_go_tool "gron"              "github.com/tomnomnom/gron"
install_go_tool "hakip2host"        "github.com/hakluke/hakip2host"
install_go_tool "gowitness"         "github.com/sensepost/gowitness"
install_go_tool "dirdar"            "github.com/m4dm0e/dirdar"
install_go_tool "scopein"           "github.com/ferreiraklet/scopein"
install_go_tool "sourcemapper"      "github.com/denandz/sourcemapper"
install_go_tool "SubOver"           "github.com/Ice3man543/SubOver"

echo -e "\n${bblue}[>] [NEW v4] Tech Fingerprinting & CVE${reset}"
install_go_tool "webanalyze"        "github.com/rverton/webanalyze/cmd/webanalyze"

# =============================================================================
printf "\n${bblue}[*] Instalando ferramentas Python${reset}\n\n"
# =============================================================================

pip_install() {
  local pkg="$1"
  printf "${byellow}  [~] %-30s${reset}" "$pkg"
  if pip3 install "$pkg" --break-system-packages -q 2>/dev/null || pip3 install "$pkg" -q 2>/dev/null; then
    echo -e " ${bgreen}OK${reset}"
  else
    echo -e " ${bred}FALHOU${reset}"
  fi
}

pip_install uro
pip_install bhedak
pip_install arjun
pip_install waymore
# semgrep: instalado via binário standalone oficial (mais confiável que pip)
if ! command -v semgrep &>/dev/null; then
  printf "${byellow}  [~] %-30s${reset}" "semgrep"
  SEMGREP_TMP=$(mktemp -d)
  # Baixa o binário standalone do GitHub Releases
  SEMGREP_VER=$(curl -s https://api.github.com/repos/semgrep/semgrep/releases/latest | grep '"tag_name"' | cut -d'"' -f4)
  SEMGREP_VER=${SEMGREP_VER:-v1.72.0}
  curl -fsSL "https://github.com/semgrep/semgrep/releases/download/${SEMGREP_VER}/semgrep-linux-amd64" \
    -o "$SEMGREP_TMP/semgrep" 2>/dev/null && \
    chmod +x "$SEMGREP_TMP/semgrep" && \
    sudo mv "$SEMGREP_TMP/semgrep" /usr/local/bin/semgrep
  rm -rf "$SEMGREP_TMP"
  command -v semgrep &>/dev/null && echo -e " ${bgreen}OK${reset}" || \
    echo -e " ${bred}FALHOU — fallback: pip3 install semgrep --break-system-packages${reset}"
else
  echo -e "${bgreen}  [=] semgrep ja instalado${reset}"
fi
pip_install sqlmap
pip_install theHarvester
pip_install googler

# =============================================================================
printf "\n${bblue}[*] Instalando gitleaks${reset}\n\n"
# =============================================================================
GITLEAKS_VER="8.18.3"
if ! command -v gitleaks &>/dev/null; then
  printf "${byellow}  [~] gitleaks v${GITLEAKS_VER}${reset}"
  wget -q -O /tmp/gitleaks.tar.gz \
    "https://github.com/gitleaks/gitleaks/releases/download/v${GITLEAKS_VER}/gitleaks_${GITLEAKS_VER}_linux_x64.tar.gz" && \
    tar -xzf /tmp/gitleaks.tar.gz -C /tmp && \
    sudo mv /tmp/gitleaks /usr/local/bin/gitleaks && \
    chmod +x /usr/local/bin/gitleaks && \
    echo -e " ${bgreen}OK${reset}" || echo -e " ${bred}FALHOU${reset}"
else
  echo -e "${bgreen}  [=] gitleaks já instalado${reset}"
fi

# =============================================================================
printf "\n${bblue}[*] Instalando TruffleHog v3 (Go binary oficial)${reset}\n\n"
# =============================================================================
if ! command -v trufflehog &>/dev/null; then
  printf "${byellow}  [~] trufflehog v3${reset}"
  curl -sSfL https://raw.githubusercontent.com/trufflesecurity/trufflehog/main/scripts/install.sh \
    | sh -s -- -b /usr/local/bin 2>/dev/null && \
    echo -e " ${bgreen}OK${reset}" || \
    echo -e " ${bred}FALHOU — alternativa: go install github.com/trufflesecurity/trufflehog/v3@latest${reset}"
else
  echo -e "${bgreen}  [=] trufflehog já instalado${reset}"
fi

# =============================================================================
printf "\n${bblue}[*] Instalando GitHub CLI (gh)${reset}\n\n"
# =============================================================================
if ! command -v gh &>/dev/null; then
  printf "${byellow}  [~] GitHub CLI${reset}"
  # Instala via binário .deb direto do GitHub Releases (mais confiável que o apt repo)
  GH_VER=$(curl -s https://api.github.com/repos/cli/cli/releases/latest | grep '"tag_name"' | cut -d'"' -f4 | tr -d v)
  GH_VER=${GH_VER:-2.49.2}
  GH_DEB="gh_${GH_VER}_linux_amd64.deb"
  wget -q -O "/tmp/${GH_DEB}" "https://github.com/cli/cli/releases/download/v${GH_VER}/${GH_DEB}" && \
    sudo dpkg -i "/tmp/${GH_DEB}" -q 2>/dev/null && \
    rm -f "/tmp/${GH_DEB}" && \
    echo -e " ${bgreen}OK${reset}" || \
    echo -e " ${bred}FALHOU — instale em: https://cli.github.com${reset}"
else
  echo -e "${bgreen}  [=] gh ja instalado${reset}"
fi

# =============================================================================
printf "\n${bblue}[*] Clonando repositórios Git${reset}\n\n"
# =============================================================================

clone_repo() {
  local name="$1" ghrepo="$2"
  printf "${byellow}  [~] %-30s${reset}" "$name"
  if [ -d "$dir/$name" ]; then
    cd "$dir/$name" && git pull -q 2>/dev/null && cd "$dir"
    echo -e " ${bgreen}atualizado${reset}"
  else
    git clone -q "https://github.com/$ghrepo" "$dir/$name" 2>/dev/null && \
      echo -e " ${bgreen}clonado${reset}" || echo -e " ${bred}FALHOU${reset}"
  fi
  cd "$dir/$name" 2>/dev/null || return
  [ -s "requirements.txt" ] && pip3 install -r requirements.txt --break-system-packages -q 2>/dev/null
  [ -s "setup.py" ]         && python3 setup.py install -q 2>/dev/null
  [ -s "Makefile" ]         && make -s 2>/dev/null && make install -s 2>/dev/null
  cd "$dir"
}

clone_repo "gf"               "tomnomnom/gf"
clone_repo "Gf-Patterns"      "1ndianl33t/Gf-Patterns"
clone_repo "LinkFinder"       "GerbenJavado/LinkFinder"
clone_repo "SecretFinder"     "m4ll0k/SecretFinder"
clone_repo "BBTz"             "m4ll0k/BBTz"
clone_repo "git-dumper"       "arthaud/git-dumper"
clone_repo "GitTools"         "internetwache/GitTools"
clone_repo "CORStest"         "RUB-NDS/CORStest"
clone_repo "CORScanner"       "chenjj/CORScanner"
clone_repo "ParamSpider"      "devanshbatham/paramspider"
clone_repo "knoxnl"           "xnl-h4ck3r/knoxnl"
clone_repo "xnLinkFinder"     "xnl-h4ck3r/xnLinkFinder"
clone_repo "Waymore"          "xnl-h4ck3r/waymore"
clone_repo "FavFreak"         "devanshbatham/FavFreak"
clone_repo "smuggler"         "defparam/smuggler"
clone_repo "nomore403"        "devploit/nomore403"
clone_repo "cloud_enum"       "initstring/cloud_enum"
clone_repo "S3Scanner"        "sa7mon/S3Scanner"
clone_repo "XSStrike"         "s0md3v/XSStrike"
clone_repo "Photon"           "s0md3v/Photon"
clone_repo "Knock"            "guelfoweb/knock"
clone_repo "DNSvalidator"     "vortexau/dnsvalidator"
clone_repo "Massdns"          "blechschmidt/massdns"
clone_repo "Dirsearch"        "maurosoria/dirsearch"
clone_repo "Interlace"        "codingo/Interlace"
clone_repo "MSwellDOTS"       "mswell/dotfiles"

# GF patterns
cp "$dir/gf/examples/"*.json  "$GF_DIR/" 2>/dev/null
cp "$dir/Gf-Patterns/"*.json  "$GF_DIR/" 2>/dev/null
wget -q -O "$GF_DIR/potential.json" \
  "https://raw.githubusercontent.com/devanshbatham/ParamSpider/master/gf_profiles/potential.json" 2>/dev/null

# =============================================================================
printf "\n${bblue}[*] Baixando wordlists${reset}\n\n"
# =============================================================================

dl() {
  local dest="$1" url="$2"
  if [ ! -f "$dest" ]; then
    printf "${byellow}  [~] %-45s${reset}" "$(basename $dest)"
    wget -q -O "$dest" "$url" && echo -e " ${bgreen}OK${reset}" || echo -e " ${bred}FALHOU${reset}"
  else
    echo -e "  ${bgreen}[=] $(basename $dest) existe${reset}"
  fi
}

SECLISTS="https://raw.githubusercontent.com/danielmiessler/SecLists/master"

# Resolvers (sempre atualiza)
wget -q -O "$LISTS/resolvers.txt"         "https://raw.githubusercontent.com/trickest/resolvers/main/resolvers.txt"
wget -q -O "$LISTS/resolvers-trusted.txt" "https://raw.githubusercontent.com/trickest/resolvers/main/resolvers-trusted.txt"

dl "$LISTS/raft-large-directories.txt"        "$SECLISTS/Discovery/Web-Content/raft-large-directories.txt"
dl "$LISTS/raft-large-directories-lower.txt"  "$SECLISTS/Discovery/Web-Content/raft-large-directories-lowercase.txt"
dl "$LISTS/raft-large-files.txt"              "$SECLISTS/Discovery/Web-Content/raft-large-files.txt"
dl "$LISTS/raft-large-words.txt"              "$SECLISTS/Discovery/Web-Content/raft-large-words.txt"
dl "$LISTS/raft-medium-directories.txt"       "$SECLISTS/Discovery/Web-Content/raft-medium-directories.txt"
dl "$LISTS/web-extensions.txt"                "$SECLISTS/Discovery/Web-Content/web-extensions.txt"
dl "$LISTS/params.txt"                        "$SECLISTS/Discovery/Web-Content/burp-parameter-names.txt"
dl "$LISTS/namelist.txt"                      "$SECLISTS/Discovery/DNS/namelist.txt"
dl "$LISTS/subdomains-top1million-5000.txt"   "$SECLISTS/Discovery/DNS/subdomains-top1million-5000.txt"
dl "$LISTS/subdomains-top1million-110000.txt" "$SECLISTS/Discovery/DNS/subdomains-top1million-110000.txt"
dl "$LISTS/XSS-OFJAAAH.txt"                  "$SECLISTS/Fuzzing/XSS/XSS-OFJAAAH.txt"
dl "$LISTS/XSS-Jhaddix.txt"                  "$SECLISTS/Fuzzing/XSS/XSS-Jhaddix.txt"
dl "$LISTS/lfi-payloads.txt"                  "$SECLISTS/Fuzzing/LFI/LFI-Jhaddix.txt"
dl "$LISTS/sqli-payloads.txt"                 "$SECLISTS/Fuzzing/SQLi/Generic-SQLi.txt"
dl "$LISTS/ssti-payloads.txt"                 "$SECLISTS/Fuzzing/template-engines-special-vars.txt"
dl "$LISTS/open-redirect.txt"                 "$SECLISTS/Fuzzing/redirect/open-redirect-payloads.txt"
dl "$LISTS/xato-net-10million-usernames.txt"  "$SECLISTS/Usernames/xato-net-10-million-usernames.txt"
dl "$LISTS/httparchive_apiroutes.txt"         "https://wordlists-cdn.assetnote.io/data/automated/httparchive_apiroutes_2024_02_19.txt"
dl "$LISTS/all.txt"                           "https://gist.githubusercontent.com/jhaddix/86a06c5dc309d08580a018c66354a056/raw/96f4e51d96b2203f19f6381c8c545b278eaa0837/all.txt"

# =============================================================================
printf "\n${bblue}[*] Atualizando nuclei templates${reset}\n\n"
# =============================================================================
nuclei -update-templates 2>/dev/null || true
echo -e "${bgreen}  [+] nuclei templates atualizados${reset}"

# Copia custom templates do dotfiles
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CUSTOM_TMPL="$SCRIPT_DIR/../custom_nuclei_templates"
if [ -d "$CUSTOM_TMPL" ]; then
  cp "$CUSTOM_TMPL"/*.yaml "$HOME/custom_nuclei_templates/" 2>/dev/null
  echo -e "${bgreen}  [+] custom nuclei templates copiados${reset}"
fi

# =============================================================================
printf "\n${bblue}[*] Configurando webanalyze${reset}\n\n"
# =============================================================================
if command -v webanalyze &>/dev/null; then
  webanalyze -update 2>/dev/null && \
    echo -e "${bgreen}  [+] webanalyze technologies.json atualizado${reset}" || true
fi

# =============================================================================
printf "\n${bgreen}╔══════════════════════════════════════════╗${reset}\n"
printf "${bgreen}║   Instalação completa! v4 pronto.        ║${reset}\n"
printf "${bgreen}╚══════════════════════════════════════════╝${reset}\n"
printf "\n${byellow}Próximos passos:${reset}\n"
printf "  1. source ~/.zshrc\n"
printf "  2. bb_help              — ver todos os comandos\n"
printf "  3. workspaceRecon <alvo> — criar workspace\n"
printf "  4. echo 'riotgames.com' > domains\n"
printf "  5. wellall              — pipeline completo\n\n"
